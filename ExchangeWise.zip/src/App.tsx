import { useState } from 'react';
import { Button } from "./components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./components/ui/avatar";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "./components/ui/alert-dialog";
import { LandingPage } from "./components/LandingPage";
import { AdminDashboard } from "./components/AdminDashboard";
import { UserDashboard } from "./components/UserDashboard";
import { VendorDashboard } from "./components/VendorDashboard";
import { SignIn } from "./components/SignIn";
import { UserLogin } from "./components/UserLogin";
import { VendorLogin } from "./components/VendorLogin";
import { Toaster } from "./components/ui/sonner";
import { toast } from "sonner@2.0.3";
import exchangeWiseLogo from 'figma:asset/8c7dbe677d8cc3b303c1a78ccbde0c1ca9d21bb9.png';
import { 
  LayoutDashboard, 
  TrendingUp, 
  CreditCard,
  Users, 
  Settings,
  LogOut,
  User,
  Gift,
  Building
} from "lucide-react";

type UserRole = 'admin' | 'user' | 'vendor' | null;
type AppView = 'landing' | 'admin-login' | 'user-login' | 'vendor-login' | 'admin-dashboard' | 'user-dashboard' | 'vendor-dashboard';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('landing');
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [activeTab, setActiveTab] = useState('dashboard');

  const sidebarItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'rewards', label: 'Rewards', icon: Gift },
    { id: 'manage-rates', label: 'Manage Rates', icon: TrendingUp },
    { id: 'transactions', label: 'Transactions', icon: CreditCard },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'vendors', label: 'Vendors', icon: Building },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const handleLogout = (role?: UserRole) => {
    const roleText = role === 'admin' ? 'Admin Panel' : role === 'user' ? 'User Account' : role === 'vendor' ? 'Vendor Account' : 'ExchangeWise';
    toast.success(`Successfully logged out from ${roleText}`);
    
    setTimeout(() => {
      setCurrentView('landing');
      setUserRole(null);
      setActiveTab('dashboard');
    }, 1000);
  };

  const handleGetStarted = () => {
    setCurrentView('user-login');
  };

  const handleUserLogin = () => {
    setCurrentView('user-login');
  };

  const handleVendorLogin = () => {
    setCurrentView('vendor-login');
  };

  const handleAdminLogin = () => {
    setCurrentView('admin-login');
  };

  const handleBackToLanding = () => {
    setCurrentView('landing');
  };

  const handleSuccessfulLogin = (role: UserRole) => {
    setUserRole(role);
    if (role === 'admin') {
      setCurrentView('admin-dashboard');
      toast.success("Welcome back to ExchangeWise Admin Panel!");
    } else if (role === 'user') {
      setCurrentView('user-dashboard');
      toast.success("Welcome to your ExchangeWise dashboard!");
    } else if (role === 'vendor') {
      setCurrentView('vendor-dashboard');
      toast.success("Welcome to your ExchangeWise vendor portal!");
    }
  };

  // Landing Page
  if (currentView === 'landing') {
    return (
      <>
        <LandingPage 
          onGetStarted={handleGetStarted}
          onUserLogin={handleUserLogin}
          onVendorLogin={handleVendorLogin}
          onAdminLogin={handleAdminLogin}
        />
        <Toaster />
      </>
    );
  }

  // User Login
  if (currentView === 'user-login') {
    return (
      <>
        <UserLogin 
          onLogin={() => handleSuccessfulLogin('user')}
          onBack={handleBackToLanding}
        />
        <Toaster />
      </>
    );
  }

  // Vendor Login
  if (currentView === 'vendor-login') {
    return (
      <>
        <VendorLogin 
          onLogin={() => handleSuccessfulLogin('vendor')}
          onBack={handleBackToLanding}
        />
        <Toaster />
      </>
    );
  }

  // Admin Login
  if (currentView === 'admin-login') {
    return (
      <>
        <SignIn onSignIn={() => handleSuccessfulLogin('admin')} />
        <Toaster />
      </>
    );
  }

  // User Dashboard
  if (currentView === 'user-dashboard' && userRole === 'user') {
    return (
      <>
        <UserDashboard onLogout={() => handleLogout('user')} />
        <Toaster />
      </>
    );
  }

  // Vendor Dashboard
  if (currentView === 'vendor-dashboard' && userRole === 'vendor') {
    return (
      <>
        <VendorDashboard onLogout={() => handleLogout('vendor')} />
        <Toaster />
      </>
    );
  }

  // Admin Dashboard (existing implementation)
  if (currentView === 'admin-dashboard' && userRole === 'admin') {

    return (
      <div className="min-h-screen bg-gray-100">
        {/* Sidebar */}
        <div className="fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-sm border-r border-gray-200">
          {/* Logo */}
          <div className="flex items-center h-16 px-6 border-b border-gray-200">
            <div className="flex items-center">
              <img 
                src={exchangeWiseLogo} 
                alt="ExchangeWise Logo" 
                className="w-8 h-8 object-contain"
              />
              <span className="ml-3 font-semibold text-gray-900">ExchangeWise</span>
            </div>
          </div>

          {/* Navigation */}
          <nav className="mt-6 px-4">
            <div className="space-y-2">
              {sidebarItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 ${
                      activeTab === item.id
                        ? 'bg-blue-50 text-blue-700 shadow-sm'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                    }`}
                  >
                    <Icon className="h-5 w-5 mr-3" />
                    {item.label}
                  </button>
                );
              })}
            </div>
          </nav>

          {/* Logout Button */}
          <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <button className="w-full flex items-center px-4 py-3 text-sm font-medium text-gray-600 hover:bg-gray-50 hover:text-gray-900 rounded-lg transition-all duration-200">
                  <LogOut className="h-5 w-5 mr-3" />
                  Logout
                </button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Confirm Logout</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to logout? You will need to sign in again to access the admin panel.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={() => handleLogout('admin')}
                    className="bg-red-600 hover:bg-red-700"
                  >
                    Yes, Logout
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>

        {/* Main Content */}
        <div className="pl-64">
          {/* Top Navbar */}
          <header className="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-6 shadow-sm">
            <div>
              <h1 className="text-xl font-semibold text-gray-900">ExchangeWise Admin Panel</h1>
            </div>
            
            <div className="flex items-center">
              <Avatar className="h-8 w-8 cursor-pointer hover:ring-2 hover:ring-blue-500 hover:ring-offset-2 transition-all">
                <AvatarImage src="/placeholder-avatar.jpg" />
                <AvatarFallback className="bg-gradient-to-br from-blue-500 to-green-500 text-white">
                  <User className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
            </div>
          </header>

          {/* Page Content */}
          <main className="p-6">
            <AdminDashboard activeTab={activeTab} setActiveTab={setActiveTab} />
          </main>
        </div>

        {/* Toast Notifications */}
        <Toaster />
      </div>
    );
  }

  // Fallback to landing page
  return (
    <>
      <LandingPage 
        onGetStarted={handleGetStarted}
        onUserLogin={handleUserLogin}
        onVendorLogin={handleVendorLogin}
        onAdminLogin={handleAdminLogin}
      />
      <Toaster />
    </>
  );
}