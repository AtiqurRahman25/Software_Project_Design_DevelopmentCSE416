import { useState } from 'react';
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "./ui/alert-dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Switch } from "./ui/switch";
import { toast } from "sonner@2.0.3";
import { 
  Globe, 
  Clock, 
  Users, 
  AlertCircle,
  Edit3,
  Trash2,
  Plus,
  CheckCircle,
  XCircle,
  UserCheck,
  AlertTriangle,
  Mail,
  User as UserIcon,
  Building,
  CreditCard,
  Activity,
  Eye,
  Filter,
  Calendar,
  Hash,
  FileText,
  Gift,
  Star,
  Award,
  Coins,
  DollarSign,
  TrendingUp,
  Wallet,
  Phone,
  MapPin,
  Send,
  Loader2
} from "lucide-react";

// Activity interface
interface ActivityLog {
  id: number;
  action: string;
  admin: string;
  timestamp: string;
  category: 'user' | 'rate' | 'system' | 'transaction';
}

// Transaction interface
interface Transaction {
  id: number;
  transactionId: string;
  userPassportId: string;
  vendorLicenseId: string;
  fromCurrency: string;
  toCurrency: string;
  amount: number;
  exchangeRate: number;
  convertedAmount: number;
  status: 'Completed' | 'Pending' | 'Failed' | 'Processing';
  date: string;
  timestamp: string;
}

// Reward interface
interface Reward {
  id: number;
  title: string;
  description: string;
  pointsRequired: number;
  category: 'Exchange' | 'Cashback' | 'Special' | 'VIP';
  status: 'Active' | 'Inactive' | 'Expired';
  validUntil: string;
  claimed: number;
  maxClaims: number;
}

// Vendor interface
interface Vendor {
  id: number;
  licenseId: string;
  businessName: string;
  ownerName: string;
  email: string;
  balance: number;
  level: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  status: 'Active' | 'Inactive' | 'Pending';
  totalRevenue: number;
  commissionsEarned: number;
  totalTransactions: number;
  joinDate: string;
  lastActive: string;
  location: string;
  phoneNumber: string;
}

const initialVendors: Vendor[] = [
  {
    id: 1,
    licenseId: "VL-BD-2024-001",
    businessName: "Global Exchange Solutions Ltd.",
    ownerName: "Ahmed Rahman",
    email: "ahmed@globalexchange.com",
    balance: 125750.50,
    level: "Gold",
    status: "Active",
    totalRevenue: 568200.00,
    commissionsEarned: 45870.50,
    totalTransactions: 348,
    joinDate: "2024-01-15",
    lastActive: "5 minutes ago",
    location: "Dhaka, Bangladesh",
    phoneNumber: "+880-1234-567890"
  },
  {
    id: 2,
    licenseId: "VL-BD-2024-002",
    businessName: "Swift Currency Exchange",
    ownerName: "Sarah Johnson",
    email: "sarah@swiftcurrency.com",
    balance: 89320.75,
    level: "Silver",
    status: "Active",
    totalRevenue: 324150.25,
    commissionsEarned: 28965.80,
    totalTransactions: 256,
    joinDate: "2024-02-20",
    lastActive: "2 hours ago",
    location: "Chittagong, Bangladesh",
    phoneNumber: "+880-1987-654321"
  },
  {
    id: 3,
    licenseId: "VL-BD-2024-003",
    businessName: "Prime Money Changers",
    ownerName: "Mohammad Ali",
    email: "ali@primemoney.com",
    balance: 234890.25,
    level: "Platinum",
    status: "Active",
    totalRevenue: 892450.75,
    commissionsEarned: 76540.20,
    totalTransactions: 567,
    joinDate: "2023-11-10",
    lastActive: "1 hour ago",
    location: "Sylhet, Bangladesh",
    phoneNumber: "+880-1555-123456"
  },
  {
    id: 4,
    licenseId: "VL-BD-2024-004",
    businessName: "City Exchange Center",
    ownerName: "Fatima Khatun",
    email: "fatima@cityexchange.com",
    balance: 45680.00,
    level: "Bronze",
    status: "Pending",
    totalRevenue: 156300.50,
    commissionsEarned: 12840.75,
    totalTransactions: 89,
    joinDate: "2024-08-01",
    lastActive: "1 day ago",
    location: "Rajshahi, Bangladesh",
    phoneNumber: "+880-1777-888999"
  },
  {
    id: 5,
    licenseId: "VL-BD-2024-005",
    businessName: "Express Money Transfer",
    ownerName: "Karim Hassan",
    email: "karim@expressmoney.com",
    balance: 67450.30,
    level: "Silver",
    status: "Inactive",
    totalRevenue: 289750.60,
    commissionsEarned: 23580.45,
    totalTransactions: 178,
    joinDate: "2024-03-25",
    lastActive: "3 days ago",
    location: "Khulna, Bangladesh",
    phoneNumber: "+880-1666-444555"
  }
];

// Mock data
const initialRecentActivity: ActivityLog[] = [
  { id: 1, action: "Updated USD/EUR rate", admin: "John Doe", timestamp: "2 minutes ago", category: 'rate' },
  { id: 2, action: "Added new user: sarah@email.com", admin: "Jane Smith", timestamp: "15 minutes ago", category: 'user' },
  { id: 3, action: "Modified GBP/USD rate", admin: "Mike Johnson", timestamp: "32 minutes ago", category: 'rate' },
  { id: 4, action: "Updated user role: Emma Davis to Admin", admin: "John Doe", timestamp: "1 hour ago", category: 'user' },
  { id: 5, action: "Updated system settings", admin: "Jane Smith", timestamp: "2 hours ago", category: 'system' },
  { id: 6, action: "Deleted user: old.user@email.com", admin: "Jane Smith", timestamp: "3 hours ago", category: 'user' },
  { id: 7, action: "Added new user: alex.brown@email.com", admin: "John Doe", timestamp: "4 hours ago", category: 'user' },
  { id: 8, action: "Updated user status: Mike Chen to Inactive", admin: "Jane Smith", timestamp: "5 hours ago", category: 'user' },
  { id: 9, action: "Transaction TXN-2024-001 completed", admin: "System", timestamp: "10 minutes ago", category: 'transaction' },
  { id: 10, action: "Transaction TXN-2024-002 failed", admin: "System", timestamp: "25 minutes ago", category: 'transaction' },
  { id: 11, action: "Transaction TXN-2024-003 completed", admin: "System", timestamp: "45 minutes ago", category: 'transaction' },
];

const initialTransactions: Transaction[] = [
  {
    id: 1,
    transactionId: "TXN-2024-001",
    userPassportId: "B23456789",
    vendorLicenseId: "VL-BD-2024-001",
    fromCurrency: "USD",
    toCurrency: "BDT",
    amount: 500,
    exchangeRate: 119.85,
    convertedAmount: 59925,
    status: "Completed",
    date: "2024-08-21",
    timestamp: "10 minutes ago"
  },
  {
    id: 2,
    transactionId: "TXN-2024-002",
    userPassportId: "D45678901",
    vendorLicenseId: "VL-BD-2024-002",
    fromCurrency: "EUR",
    toCurrency: "BDT",
    amount: 300,
    exchangeRate: 130.45,
    convertedAmount: 39135,
    status: "Failed",
    date: "2024-08-21",
    timestamp: "25 minutes ago"
  },
  {
    id: 3,
    transactionId: "TXN-2024-003",
    userPassportId: "A12345678",
    vendorLicenseId: "VL-BD-2024-001",
    fromCurrency: "GBP",
    toCurrency: "BDT",
    amount: 200,
    exchangeRate: 151.20,
    convertedAmount: 30240,
    status: "Completed",
    date: "2024-08-21",
    timestamp: "45 minutes ago"
  },
  {
    id: 4,
    transactionId: "TXN-2024-004",
    userPassportId: "E56789012",
    vendorLicenseId: "VL-BD-2024-003",
    fromCurrency: "AUD",
    toCurrency: "BDT",
    amount: 150,
    exchangeRate: 79.35,
    convertedAmount: 11902.5,
    status: "Processing",
    date: "2024-08-21",
    timestamp: "1 hour ago"
  },
  {
    id: 5,
    transactionId: "TXN-2024-005",
    userPassportId: "C34567890",
    vendorLicenseId: "VL-BD-2024-002",
    fromCurrency: "USD",
    toCurrency: "BDT",
    amount: 750,
    exchangeRate: 119.85,
    convertedAmount: 89887.5,
    status: "Pending",
    date: "2024-08-20",
    timestamp: "2 hours ago"
  },
  {
    id: 6,
    transactionId: "TXN-2024-006",
    userPassportId: "B23456789",
    vendorLicenseId: "VL-BD-2024-001",
    fromCurrency: "JPY",
    toCurrency: "BDT",
    amount: 10000,
    exchangeRate: 0.80,
    convertedAmount: 8000,
    status: "Completed",
    date: "2024-08-20",
    timestamp: "3 hours ago"
  },
  {
    id: 7,
    transactionId: "TXN-2024-007",
    userPassportId: "D45678901",
    vendorLicenseId: "VL-BD-2024-003",
    fromCurrency: "EUR",
    toCurrency: "BDT",
    amount: 450,
    exchangeRate: 130.45,
    convertedAmount: 58702.5,
    status: "Completed",
    date: "2024-08-20",
    timestamp: "4 hours ago"
  },
  {
    id: 8,
    transactionId: "TXN-2024-008",
    userPassportId: "A12345678",
    vendorLicenseId: "VL-BD-2024-002",
    fromCurrency: "USD",
    toCurrency: "BDT",
    amount: 1000,
    exchangeRate: 119.85,
    convertedAmount: 119850,
    status: "Failed",
    date: "2024-08-19",
    timestamp: "1 day ago"
  }
];

const initialCurrencyRates = [
  { id: 1, pair: "USD/BDT", rate: 119.85, lastUpdated: "2 minutes ago" },
  { id: 2, pair: "EUR/BDT", rate: 130.45, lastUpdated: "5 minutes ago" },
  { id: 3, pair: "GBP/BDT", rate: 151.20, lastUpdated: "8 minutes ago" },
  { id: 4, pair: "JPY/BDT", rate: 0.80, lastUpdated: "12 minutes ago" },
  { id: 5, pair: "AUD/BDT", rate: 79.35, lastUpdated: "15 minutes ago" },
];

const initialUsers = [
  { id: 1, name: "John Doe", email: "john.doe@email.com", role: "Admin", status: "Active", passportNo: "A12345678" },
  { id: 2, name: "Sarah Wilson", email: "sarah@email.com", role: "User", status: "Active", passportNo: "B23456789" },
  { id: 3, name: "Mike Chen", email: "mike.chen@email.com", role: "Vendor", status: "Inactive", passportNo: "C34567890" },
  { id: 4, name: "Emma Davis", email: "emma.davis@email.com", role: "User", status: "Active", passportNo: "D45678901" },
  { id: 5, name: "Alex Brown", email: "alex.brown@email.com", role: "Admin", status: "Active", passportNo: "E56789012" },
];

const currencies = [
  { code: "USD", name: "US Dollar" },
  { code: "EUR", name: "Euro" },
  { code: "GBP", name: "British Pound" },
  { code: "JPY", name: "Japanese Yen" },
  { code: "AUD", name: "Australian Dollar" },
  { code: "BDT", name: "Bangladeshi Taka" },
  { code: "CAD", name: "Canadian Dollar" },
  { code: "CHF", name: "Swiss Franc" },
  { code: "CNY", name: "Chinese Yuan" },
  { code: "INR", name: "Indian Rupee" },
];

const userRoles = [
  { value: "Admin", label: "Administrator" },
  { value: "User", label: "User" },
  { value: "Vendor", label: "Vendor" },
];

const userStatuses = [
  { value: "Active", label: "Active" },
  { value: "Inactive", label: "Inactive" },
];

const initialRewards: Reward[] = [
  {
    id: 1,
    title: "First Exchange Bonus",
    description: "Get 100 reward points for your first currency exchange",
    pointsRequired: 0,
    category: "Exchange",
    status: "Active",
    validUntil: "2024-12-31",
    claimed: 145,
    maxClaims: 1000
  },
  {
    id: 2,
    title: "5% Cashback on Large Exchanges",
    description: "Earn 5% cashback on exchanges over $1000",
    pointsRequired: 0,
    category: "Cashback",
    status: "Active",
    validUntil: "2024-10-31",
    claimed: 89,
    maxClaims: 500
  },
  {
    id: 3,
    title: "VIP Exchange Rate",
    description: "Access to premium exchange rates for 30 days",
    pointsRequired: 2000,
    category: "VIP",
    status: "Active",
    validUntil: "2024-12-31",
    claimed: 23,
    maxClaims: 100
  },
  {
    id: 4,
    title: "Free Transaction Fee",
    description: "Waive transaction fees for your next 5 exchanges",
    pointsRequired: 500,
    category: "Special",
    status: "Active",
    validUntil: "2024-11-30",
    claimed: 67,
    maxClaims: 200
  },
  {
    id: 5,
    title: "Double Points Weekend",
    description: "Earn double points on all weekend transactions",
    pointsRequired: 0,
    category: "Special",
    status: "Expired",
    validUntil: "2024-08-18",
    claimed: 234,
    maxClaims: 1000
  }
];

interface AdminDashboardProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

interface CurrencyRate {
  id: number;
  pair: string;
  rate: number;
  lastUpdated: string;
}

interface User {
  id: number;
  name: string;
  email: string;
  role: string;
  status: string;
  passportNo: string;
}

interface RateFormData {
  baseCurrency: string;
  targetCurrency: string;
  exchangeRate: string;
}

interface UserFormData {
  name: string;
  email: string;
  role: string;
  status: string;
  passportNo: string;
}

export function AdminDashboard({ activeTab, setActiveTab }: AdminDashboardProps) {
  const [currencyRates, setCurrencyRates] = useState<CurrencyRate[]>(initialCurrencyRates);
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [vendors, setVendors] = useState<Vendor[]>(initialVendors);
  const [transactions] = useState<Transaction[]>(initialTransactions);
  const [rewards, setRewards] = useState<Reward[]>(initialRewards);
  const [recentActivity, setRecentActivity] = useState<ActivityLog[]>(initialRecentActivity);
  const [isAddRateModalOpen, setIsAddRateModalOpen] = useState(false);
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [editingRate, setEditingRate] = useState<CurrencyRate | null>(null);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [deleteRateId, setDeleteRateId] = useState<number | null>(null);
  const [deleteUserId, setDeleteUserId] = useState<number | null>(null);
  const [isSendingToBangladeshBank, setIsSendingToBangladeshBank] = useState(false);
  
  // Form state for rates
  const [rateFormData, setRateFormData] = useState<RateFormData>({
    baseCurrency: '',
    targetCurrency: '',
    exchangeRate: ''
  });
  const [rateFormErrors, setRateFormErrors] = useState<Partial<RateFormData>>({});

  // Form state for users
  const [userFormData, setUserFormData] = useState<UserFormData>({
    name: '',
    email: '',
    role: '',
    status: '',
    passportNo: ''
  });
  const [userFormErrors, setUserFormErrors] = useState<Partial<UserFormData>>({});

  // Helper function to add activity log
  const addActivityLog = (action: string, category: 'user' | 'rate' | 'system' | 'transaction', admin: string = "Current Admin") => {
    const newActivity: ActivityLog = {
      id: Math.max(...recentActivity.map(a => a.id), 0) + 1,
      action,
      admin,
      timestamp: "Just now",
      category
    };
    setRecentActivity(prev => [newActivity, ...prev].slice(0, 10)); // Keep only latest 10 activities
  };

  // Filter activities by category
  const getFilteredActivities = (category?: 'user' | 'rate' | 'system' | 'transaction') => {
    if (!category) return recentActivity.slice(0, 5);
    return recentActivity.filter(activity => activity.category === category).slice(0, 5);
  };

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100"><CheckCircle className="w-3 h-3 mr-1" />Active</Badge>;
      case 'inactive':
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100"><XCircle className="w-3 h-3 mr-1" />Inactive</Badge>;
      case 'admin':
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100"><UserCheck className="w-3 h-3 mr-1" />Admin</Badge>;
      case 'user':
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100"><UserIcon className="w-3 h-3 mr-1" />User</Badge>;
      case 'vendor':
        return <Badge className="bg-orange-100 text-orange-800 hover:bg-orange-100"><Building className="w-3 h-3 mr-1" />Vendor</Badge>;
      case 'bronze':
        return <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100"><Award className="w-3 h-3 mr-1" />Bronze</Badge>;
      case 'silver':
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100"><Award className="w-3 h-3 mr-1" />Silver</Badge>;
      case 'gold':
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100"><Award className="w-3 h-3 mr-1" />Gold</Badge>;
      case 'platinum':
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100"><Award className="w-3 h-3 mr-1" />Platinum</Badge>;
      case 'completed':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100"><CheckCircle className="w-3 h-3 mr-1" />Completed</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'failed':
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100"><XCircle className="w-3 h-3 mr-1" />Failed</Badge>;
      case 'processing':
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100"><AlertTriangle className="w-3 h-3 mr-1" />Processing</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const resetRateForm = () => {
    setRateFormData({
      baseCurrency: '',
      targetCurrency: '',
      exchangeRate: ''
    });
    setRateFormErrors({});
  };

  const resetUserForm = () => {
    setUserFormData({
      name: '',
      email: '',
      role: '',
      status: '',
      passportNo: ''
    });
    setUserFormErrors({});
  };

  // Rate management functions
  const handleEditRate = (rate: CurrencyRate) => {
    const [baseCurrency, targetCurrency] = rate.pair.split('/');
    setEditingRate(rate);
    setRateFormData({
      baseCurrency,
      targetCurrency,
      exchangeRate: rate.rate.toString()
    });
    setIsAddRateModalOpen(true);
  };

  const handleCloseRateModal = () => {
    setIsAddRateModalOpen(false);
    setEditingRate(null);
    resetRateForm();
  };

  const validateRateForm = (): boolean => {
    const errors: Partial<RateFormData> = {};

    if (!rateFormData.baseCurrency) {
      errors.baseCurrency = 'Base currency is required';
    }

    if (!rateFormData.targetCurrency) {
      errors.targetCurrency = 'Target currency is required';
    }

    if (rateFormData.baseCurrency === rateFormData.targetCurrency) {
      errors.targetCurrency = 'Target currency must be different from base currency';
    }

    if (!rateFormData.exchangeRate) {
      errors.exchangeRate = 'Exchange rate is required';
    } else {
      const rate = parseFloat(rateFormData.exchangeRate);
      if (isNaN(rate) || rate <= 0) {
        errors.exchangeRate = 'Exchange rate must be a positive number';
      }
    }

    // Check if currency pair already exists (only when adding new)
    if (!editingRate) {
      const pair = `${rateFormData.baseCurrency}/${rateFormData.targetCurrency}`;
      const exists = currencyRates.some(rate => rate.pair === pair);
      if (exists) {
        errors.baseCurrency = 'This currency pair already exists';
      }
    }

    setRateFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSaveRate = () => {
    if (!validateRateForm()) {
      toast.error("Please fix the form errors before saving.");
      return;
    }

    const rate = parseFloat(rateFormData.exchangeRate);
    const pair = `${rateFormData.baseCurrency}/${rateFormData.targetCurrency}`;
    const timestamp = "Just now";

    if (editingRate) {
      // Update existing rate
      setCurrencyRates(prev =>
        prev.map(r =>
          r.id === editingRate.id
            ? { ...r, pair, rate, lastUpdated: timestamp }
            : r
        )
      );
      addActivityLog(`Updated ${pair} exchange rate to ${rate}`, 'rate');
      toast.success(`Successfully updated ${pair} exchange rate to ${rate}`);
    } else {
      // Add new rate
      const newRate: CurrencyRate = {
        id: Math.max(...currencyRates.map(r => r.id)) + 1,
        pair,
        rate,
        lastUpdated: timestamp
      };
      setCurrencyRates(prev => [...prev, newRate]);
      addActivityLog(`Added new exchange rate for ${pair}`, 'rate');
      toast.success(`Successfully added new exchange rate for ${pair}`);
    }

    handleCloseRateModal();
  };

  const handleDeleteRate = (id: number) => {
    const rate = currencyRates.find(r => r.id === id);
    if (rate) {
      setCurrencyRates(prev => prev.filter(r => r.id !== id));
      addActivityLog(`Deleted ${rate.pair} exchange rate`, 'rate');
      toast.success(`Successfully deleted ${rate.pair} exchange rate`);
    }
    setDeleteRateId(null);
  };

  const handleRateFormChange = (field: keyof RateFormData, value: string) => {
    setRateFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (rateFormErrors[field]) {
      setRateFormErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  // User management functions
  const handleEditUser = (user: User) => {
    setEditingUser(user);
    setUserFormData({
      name: user.name,
      email: user.email,
      role: user.role,
      status: user.status,
      passportNo: user.passportNo
    });
    setIsAddUserModalOpen(true);
  };

  const handleCloseUserModal = () => {
    setIsAddUserModalOpen(false);
    setEditingUser(null);
    resetUserForm();
  };

  const validateUserForm = (): boolean => {
    const errors: Partial<UserFormData> = {};

    if (!userFormData.name.trim()) {
      errors.name = 'Name is required';
    }

    if (!userFormData.email.trim()) {
      errors.email = 'Email is required';
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(userFormData.email)) {
        errors.email = 'Please enter a valid email address';
      }
    }

    if (!userFormData.role) {
      errors.role = 'Role is required';
    }

    if (!userFormData.status) {
      errors.status = 'Status is required';
    }

    if (!userFormData.passportNo.trim()) {
      errors.passportNo = 'Passport number is required';
    } else {
      // Basic passport number validation (alphanumeric, 6-12 characters)
      const passportRegex = /^[A-Z0-9]{6,12}$/;
      if (!passportRegex.test(userFormData.passportNo.toUpperCase())) {
        errors.passportNo = 'Passport number must be 6-12 alphanumeric characters';
      }
    }

    // Check if email already exists (only when adding new or changing email)
    if (!editingUser || editingUser.email !== userFormData.email) {
      const emailExists = users.some(user => user.email.toLowerCase() === userFormData.email.toLowerCase());
      if (emailExists) {
        errors.email = 'This email address is already in use';
      }
    }

    // Check if passport number already exists (only when adding new or changing passport)
    if (!editingUser || editingUser.passportNo !== userFormData.passportNo) {
      const passportExists = users.some(user => user.passportNo.toUpperCase() === userFormData.passportNo.toUpperCase());
      if (passportExists) {
        errors.passportNo = 'This passport number is already in use';
      }
    }

    setUserFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSaveUser = () => {
    if (!validateUserForm()) {
      toast.error("Please fix the form errors before saving.");
      return;
    }

    // Normalize passport number to uppercase
    const normalizedPassportNo = userFormData.passportNo.toUpperCase();

    if (editingUser) {
      // Check what changed for activity log
      const changes = [];
      if (editingUser.name !== userFormData.name) changes.push(`name to ${userFormData.name}`);
      if (editingUser.email !== userFormData.email) changes.push(`email to ${userFormData.email}`);
      if (editingUser.role !== userFormData.role) changes.push(`role to ${userFormData.role}`);
      if (editingUser.status !== userFormData.status) changes.push(`status to ${userFormData.status}`);
      if (editingUser.passportNo !== normalizedPassportNo) changes.push(`passport number`);

      // Update existing user
      setUsers(prev =>
        prev.map(u =>
          u.id === editingUser.id
            ? { ...u, ...userFormData, passportNo: normalizedPassportNo }
            : u
        )
      );

      if (changes.length > 0) {
        addActivityLog(`Updated user ${editingUser.name}: ${changes.join(', ')}`, 'user');
      }
      toast.success(`Successfully updated user ${userFormData.name}`);
    } else {
      // Add new user
      const newUser: User = {
        id: Math.max(...users.map(u => u.id)) + 1,
        ...userFormData,
        passportNo: normalizedPassportNo
      };
      setUsers(prev => [...prev, newUser]);
      addActivityLog(`Added new user: ${userFormData.email}`, 'user');
      toast.success(`Successfully added new user ${userFormData.name}`);
    }

    handleCloseUserModal();
  };

  const handleDeleteUser = (id: number) => {
    const user = users.find(u => u.id === id);
    if (user) {
      setUsers(prev => prev.filter(u => u.id !== id));
      addActivityLog(`Deleted user: ${user.email}`, 'user');
      toast.success(`Successfully deleted user ${user.name}`);
    }
    setDeleteUserId(null);
  };

  const handleUserFormChange = (field: keyof UserFormData, value: string) => {
    setUserFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (userFormErrors[field]) {
      setUserFormErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const activeUsersCount = users.filter(user => user.status === 'Active').length;

  // Bangladesh Bank data submission function
  const handleSendToBangladeshBank = async () => {
    setIsSendingToBangladeshBank(true);
    
    try {
      // Get completed transactions for submission
      const completedTransactions = transactions.filter(t => t.status === 'Completed');
      
      if (completedTransactions.length === 0) {
        toast.error("No completed transactions to send to Bangladesh Bank");
        setIsSendingToBangladeshBank(false);
        return;
      }

      // Prepare data for Bangladesh Bank
      const bankData = {
        submissionDate: new Date().toISOString(),
        totalTransactions: completedTransactions.length,
        totalVolume: completedTransactions.reduce((sum, t) => sum + t.convertedAmount, 0),
        currency: "BDT",
        exchangeRates: currencyRates.map(rate => ({
          pair: rate.pair,
          rate: rate.rate,
          lastUpdated: rate.lastUpdated
        })),
        transactions: completedTransactions.map(t => ({
          transactionId: t.transactionId,
          userPassportId: t.userPassportId,
          vendorLicenseId: t.vendorLicenseId,
          fromCurrency: t.fromCurrency,
          toCurrency: t.toCurrency,
          amount: t.amount,
          exchangeRate: t.exchangeRate,
          convertedAmount: t.convertedAmount,
          date: t.date,
          timestamp: t.timestamp
        })),
        vendors: vendors.filter(v => v.status === 'Active').map(v => ({
          licenseId: v.licenseId,
          businessName: v.businessName,
          ownerName: v.ownerName,
          location: v.location,
          totalRevenue: v.totalRevenue,
          totalTransactions: v.totalTransactions
        }))
      };

      // Simulate API call to Bangladesh Bank
      await new Promise(resolve => setTimeout(resolve, 3000));

      // Log submission for activity tracking
      addActivityLog(
        `Submitted ${completedTransactions.length} transactions (${bankData.totalVolume.toLocaleString()} ৳) to Bangladesh Bank`, 
        'system'
      );

      toast.success(
        `Successfully sent ${completedTransactions.length} transactions to Bangladesh Bank. Total volume: ${bankData.totalVolume.toLocaleString()} ৳`
      );

      // Log the data being sent (in real implementation, this would be sent to actual Bangladesh Bank API)
      console.log('Data sent to Bangladesh Bank:', bankData);
      
    } catch (error) {
      console.error('Error sending data to Bangladesh Bank:', error);
      toast.error("Failed to send data to Bangladesh Bank. Please try again.");
      addActivityLog("Failed to submit data to Bangladesh Bank", 'system');
    } finally {
      setIsSendingToBangladeshBank(false);
    }
  };

  if (activeTab === 'dashboard') {
    return (
      <div className="space-y-6">
        {/* Statistics Cards */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Currencies Managed</CardTitle>
              <Globe className="h-5 w-5 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{currencyRates.length}</div>
              <p className="text-xs text-green-600 mt-1">
                +2 new this month
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Last Update Time</CardTitle>
              <Clock className="h-5 w-5 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">2 min</div>
              <p className="text-xs text-gray-500 mt-1">
                All rates synchronized
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Active Users</CardTitle>
              <Users className="h-5 w-5 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{activeUsersCount}</div>
              <p className="text-xs text-green-600 mt-1">
                +12% from last week
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Pending Changes</CardTitle>
              <AlertCircle className="h-5 w-5 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">3</div>
              <p className="text-xs text-orange-600 mt-1">
                Require approval
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity Table */}
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Recent Activity</CardTitle>
            <p className="text-sm text-gray-500">Last 5 system updates</p>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="font-medium text-gray-700">Action</TableHead>
                  <TableHead className="font-medium text-gray-700">Admin</TableHead>
                  <TableHead className="font-medium text-gray-700">Timestamp</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {getFilteredActivities().map((activity) => (
                  <TableRow key={activity.id} className="hover:bg-gray-50">
                    <TableCell className="font-medium">{activity.action}</TableCell>
                    <TableCell>{activity.admin}</TableCell>
                    <TableCell className="text-gray-500">{activity.timestamp}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (activeTab === 'manage-rates') {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">Manage Rates</h2>
            <p className="text-gray-500">Monitor and update currency exchange rates</p>
          </div>
          <Dialog open={isAddRateModalOpen} onOpenChange={setIsAddRateModalOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white shadow-sm" onClick={resetRateForm}>
                <Plus className="h-4 w-4 mr-2" />
                Add New Rate
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>{editingRate ? 'Edit Rate' : 'Add New Rate'}</DialogTitle>
                <DialogDescription>
                  {editingRate ? 'Update the exchange rate below.' : 'Add a new currency exchange rate to the system.'}
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="baseCurrency" className="text-right">
                    From
                  </Label>
                  <Select 
                    value={rateFormData.baseCurrency} 
                    onValueChange={(value) => handleRateFormChange('baseCurrency', value)}
                    disabled={!!editingRate}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select base currency" />
                    </SelectTrigger>
                    <SelectContent>
                      {currencies.map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          {currency.code} - {currency.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {rateFormErrors.baseCurrency && (
                    <div className="col-span-4 text-red-500 text-sm">{rateFormErrors.baseCurrency}</div>
                  )}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="targetCurrency" className="text-right">
                    To
                  </Label>
                  <Select 
                    value={rateFormData.targetCurrency} 
                    onValueChange={(value) => handleRateFormChange('targetCurrency', value)}
                    disabled={!!editingRate}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select target currency" />
                    </SelectTrigger>
                    <SelectContent>
                      {currencies.map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          {currency.code} - {currency.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {rateFormErrors.targetCurrency && (
                    <div className="col-span-4 text-red-500 text-sm">{rateFormErrors.targetCurrency}</div>
                  )}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="exchangeRate" className="text-right">
                    Rate
                  </Label>
                  <Input
                    id="exchangeRate"
                    type="number"
                    step="0.01"
                    value={rateFormData.exchangeRate}
                    onChange={(e) => handleRateFormChange('exchangeRate', e.target.value)}
                    className="col-span-3"
                    placeholder="Enter exchange rate"
                  />
                  {rateFormErrors.exchangeRate && (
                    <div className="col-span-4 text-red-500 text-sm">{rateFormErrors.exchangeRate}</div>
                  )}
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={handleCloseRateModal}>
                  Cancel
                </Button>
                <Button onClick={handleSaveRate}>
                  {editingRate ? 'Update Rate' : 'Save Rate'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle>Exchange Rates</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Currency Pair</TableHead>
                  <TableHead>Exchange Rate</TableHead>
                  <TableHead>Last Updated</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {currencyRates.map((rate) => (
                  <TableRow key={rate.id}>
                    <TableCell className="font-medium">{rate.pair}</TableCell>
                    <TableCell>{rate.rate.toFixed(4)}</TableCell>
                    <TableCell className="text-gray-500">{rate.lastUpdated}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditRate(rate)}
                        >
                          <Edit3 className="h-3 w-3 mr-1" />
                          Edit
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">
                              <Trash2 className="h-3 w-3 mr-1" />
                              Delete
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Exchange Rate</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete the {rate.pair} exchange rate? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDeleteRate(rate.id)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (activeTab === 'transactions') {
    const totalTransactions = transactions.length;
    const completedTransactions = transactions.filter(t => t.status === 'Completed').length;
    const pendingTransactions = transactions.filter(t => t.status === 'Pending').length;
    const failedTransactions = transactions.filter(t => t.status === 'Failed').length;
    const totalVolume = transactions
      .filter(t => t.status === 'Completed')
      .reduce((sum, t) => sum + t.convertedAmount, 0);

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">Transactions</h2>
            <p className="text-gray-500">Monitor all currency exchange transactions</p>
          </div>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              className="flex items-center"
              onClick={handleSendToBangladeshBank}
              disabled={isSendingToBangladeshBank}
            >
              {isSendingToBangladeshBank ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Send className="h-4 w-4 mr-2" />
              )}
              {isSendingToBangladeshBank ? 'Sending...' : 'Send data to Bangladesh Bank'}
            </Button>
            <Button variant="outline" className="flex items-center">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
            <Button variant="outline" className="flex items-center">
              <Activity className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        {/* Transaction Statistics */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Transactions</CardTitle>
              <Hash className="h-5 w-5 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{totalTransactions}</div>
              <p className="text-xs text-green-600 mt-1">
                +15% from last month
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Completed</CardTitle>
              <CheckCircle className="h-5 w-5 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{completedTransactions}</div>
              <p className="text-xs text-gray-500 mt-1">
                {Math.round((completedTransactions/totalTransactions)*100)}% success rate
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Volume</CardTitle>
              <CreditCard className="h-5 w-5 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{totalVolume.toLocaleString()} ৳</div>
              <p className="text-xs text-green-600 mt-1">
                +22% from last month
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Failed Transactions</CardTitle>
              <AlertTriangle className="h-5 w-5 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{failedTransactions}</div>
              <p className="text-xs text-red-600 mt-1">
                {Math.round((failedTransactions/totalTransactions)*100)}% failure rate
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Bangladesh Bank Submission Status */}
        <Card className="bg-blue-50 border-blue-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-blue-900">Bangladesh Bank Data Submission</CardTitle>
            <p className="text-sm text-blue-700">
              Regulatory compliance requires periodic submission of transaction data to Bangladesh Bank.
              {transactions.filter(t => t.status === 'Completed').length > 0 && (
                <span className="block mt-1">
                  Ready to submit: {transactions.filter(t => t.status === 'Completed').length} completed transactions
                </span>
              )}
            </p>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <div className="text-sm font-medium text-blue-900">Last Submission</div>
                <div className="text-sm text-blue-700">August 25, 2024 at 3:45 PM</div>
              </div>
              <Button 
                onClick={handleSendToBangladeshBank}
                disabled={isSendingToBangladeshBank || transactions.filter(t => t.status === 'Completed').length === 0}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                {isSendingToBangladeshBank ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Sending to Bangladesh Bank...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    Submit to Bangladesh Bank
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Transactions Table */}
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle>Recent Transactions</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Transaction ID</TableHead>
                  <TableHead>User/Vendor</TableHead>
                  <TableHead>Exchange</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.map((transaction) => (
                  <TableRow key={transaction.id} className="hover:bg-gray-50">
                    <TableCell className="font-medium">{transaction.transactionId}</TableCell>
                    <TableCell>
                      <div>
                        <div className="text-sm font-medium">User: {transaction.userPassportId}</div>
                        <div className="text-sm text-gray-500">Vendor: {transaction.vendorLicenseId}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        {transaction.fromCurrency} → {transaction.toCurrency}
                        <div className="text-xs text-gray-500">
                          Rate: {transaction.exchangeRate.toFixed(4)}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{transaction.amount.toLocaleString()} {transaction.fromCurrency}</div>
                        <div className="text-sm text-gray-500">{transaction.convertedAmount.toLocaleString()} {transaction.toCurrency}</div>
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                    <TableCell>
                      <div>
                        <div className="text-sm">{transaction.date}</div>
                        <div className="text-xs text-gray-500">{transaction.timestamp}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm">
                        <Eye className="h-3 w-3 mr-1" />
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (activeTab === 'users') {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">User Management</h2>
            <p className="text-gray-500">Manage system users and their permissions</p>
          </div>
          <Dialog open={isAddUserModalOpen} onOpenChange={setIsAddUserModalOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white shadow-sm" onClick={resetUserForm}>
                <Plus className="h-4 w-4 mr-2" />
                Add New User
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>{editingUser ? 'Edit User' : 'Add New User'}</DialogTitle>
                <DialogDescription>
                  {editingUser ? 'Update user information below.' : 'Add a new user to the system.'}
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">
                    Name
                  </Label>
                  <Input
                    id="name"
                    value={userFormData.name}
                    onChange={(e) => handleUserFormChange('name', e.target.value)}
                    className="col-span-3"
                    placeholder="Enter full name"
                  />
                  {userFormErrors.name && (
                    <div className="col-span-4 text-red-500 text-sm">{userFormErrors.name}</div>
                  )}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="email" className="text-right">
                    Email
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={userFormData.email}
                    onChange={(e) => handleUserFormChange('email', e.target.value)}
                    className="col-span-3"
                    placeholder="Enter email address"
                  />
                  {userFormErrors.email && (
                    <div className="col-span-4 text-red-500 text-sm">{userFormErrors.email}</div>
                  )}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="role" className="text-right">
                    Role
                  </Label>
                  <Select 
                    value={userFormData.role} 
                    onValueChange={(value) => handleUserFormChange('role', value)}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select user role" />
                    </SelectTrigger>
                    <SelectContent>
                      {userRoles.map((role) => (
                        <SelectItem key={role.value} value={role.value}>
                          {role.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {userFormErrors.role && (
                    <div className="col-span-4 text-red-500 text-sm">{userFormErrors.role}</div>
                  )}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="status" className="text-right">
                    Status
                  </Label>
                  <Select 
                    value={userFormData.status} 
                    onValueChange={(value) => handleUserFormChange('status', value)}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      {userStatuses.map((status) => (
                        <SelectItem key={status.value} value={status.value}>
                          {status.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {userFormErrors.status && (
                    <div className="col-span-4 text-red-500 text-sm">{userFormErrors.status}</div>
                  )}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="passportNo" className="text-right">
                    Passport No
                  </Label>
                  <Input
                    id="passportNo"
                    value={userFormData.passportNo}
                    onChange={(e) => handleUserFormChange('passportNo', e.target.value.toUpperCase())}
                    className="col-span-3"
                    placeholder="Enter passport number"
                  />
                  {userFormErrors.passportNo && (
                    <div className="col-span-4 text-red-500 text-sm">{userFormErrors.passportNo}</div>
                  )}
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={handleCloseUserModal}>
                  Cancel
                </Button>
                <Button onClick={handleSaveUser}>
                  {editingUser ? 'Update User' : 'Add User'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle>System Users</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Passport No</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.name}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>{getStatusBadge(user.role)}</TableCell>
                    <TableCell>{getStatusBadge(user.status)}</TableCell>
                    <TableCell className="font-mono text-sm">{user.passportNo}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditUser(user)}
                        >
                          <Edit3 className="h-3 w-3 mr-1" />
                          Edit
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">
                              <Trash2 className="h-3 w-3 mr-1" />
                              Delete
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete User</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete {user.name}? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDeleteUser(user.id)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (activeTab === 'vendors') {
    const activeVendorsCount = vendors.filter(vendor => vendor.status === 'Active').length;
    const totalVendorBalance = vendors.reduce((sum, vendor) => sum + vendor.balance, 0);
    const totalVendorRevenue = vendors.reduce((sum, vendor) => sum + vendor.totalRevenue, 0);
    const totalCommissions = vendors.reduce((sum, vendor) => sum + vendor.commissionsEarned, 0);

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">Vendor Management</h2>
            <p className="text-gray-500">Monitor and manage authorized vendors</p>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" className="flex items-center">
              <Filter className="h-4 w-4 mr-2" />
              Filter
            </Button>
            <Button variant="outline" className="flex items-center">
              <Activity className="h-4 w-4 mr-2" />
              Reports
            </Button>
          </div>
        </div>

        {/* Vendor Statistics */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Vendors</CardTitle>
              <Building className="h-5 w-5 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{vendors.length}</div>
              <p className="text-xs text-green-600 mt-1">
                +2 new this month
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Active Vendors</CardTitle>
              <CheckCircle className="h-5 w-5 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{activeVendorsCount}</div>
              <p className="text-xs text-gray-500 mt-1">
                {Math.round((activeVendorsCount/vendors.length)*100)}% of total
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Balance</CardTitle>
              <Wallet className="h-5 w-5 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{totalVendorBalance.toLocaleString()} ৳</div>
              <p className="text-xs text-green-600 mt-1">
                +15% from last week
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Revenue</CardTitle>
              <DollarSign className="h-5 w-5 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{totalVendorRevenue.toLocaleString()} ৳</div>
              <p className="text-xs text-green-600 mt-1">
                +18% from last month
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Vendor Performance Overview */}
        <div className="grid lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 bg-white shadow-sm">
            <CardHeader>
              <CardTitle>Top Performing Vendors</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {vendors
                  .filter(vendor => vendor.status === 'Active')
                  .sort((a, b) => b.totalRevenue - a.totalRevenue)
                  .slice(0, 5)
                  .map((vendor, index) => (
                    <div key={vendor.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          index === 0 ? 'bg-yellow-100 text-yellow-600' :
                          index === 1 ? 'bg-gray-100 text-gray-600' :
                          index === 2 ? 'bg-amber-100 text-amber-600' :
                          'bg-blue-100 text-blue-600'
                        }`}>
                          <span className="font-bold text-sm">#{index + 1}</span>
                        </div>
                        <div>
                          <div className="font-medium">{vendor.businessName}</div>
                          <div className="text-sm text-gray-500">{vendor.ownerName} • {getStatusBadge(vendor.level)}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-green-600">{vendor.totalRevenue.toLocaleString()} ৳</div>
                        <div className="text-sm text-gray-500">{vendor.totalTransactions} transactions</div>
                      </div>
                    </div>
                  ))
                }
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm">
            <CardHeader>
              <CardTitle>Vendor Levels</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {['Platinum', 'Gold', 'Silver', 'Bronze'].map((level) => {
                  const count = vendors.filter(v => v.level === level).length;
                  const percentage = (count / vendors.length) * 100;
                  return (
                    <div key={level} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="flex items-center space-x-2">
                          {getStatusBadge(level)}
                          <span className="text-sm font-medium">{level}</span>
                        </span>
                        <span className="text-sm font-bold">{count}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            level === 'Platinum' ? 'bg-purple-500' :
                            level === 'Gold' ? 'bg-yellow-500' :
                            level === 'Silver' ? 'bg-gray-500' : 'bg-amber-600'
                          }`}
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Vendors Table */}
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle>All Vendors</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Vendor Details</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Balance</TableHead>
                  <TableHead>Level</TableHead>
                  <TableHead>Revenue</TableHead>
                  <TableHead>Transactions</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {vendors.map((vendor) => (
                  <TableRow key={vendor.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div>
                        <div className="font-medium">{vendor.businessName}</div>
                        <div className="text-sm text-gray-500">{vendor.licenseId}</div>
                        <div className="text-sm text-gray-500">Owner: {vendor.ownerName}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="flex items-center text-sm text-gray-600 mb-1">
                          <Mail className="h-3 w-3 mr-1" />
                          {vendor.email}
                        </div>
                        <div className="flex items-center text-sm text-gray-600 mb-1">
                          <Phone className="h-3 w-3 mr-1" />
                          {vendor.phoneNumber}
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="h-3 w-3 mr-1" />
                          {vendor.location}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-bold text-lg">{vendor.balance.toLocaleString()} ৳</div>
                      <div className="text-sm text-gray-500">Current balance</div>
                    </TableCell>
                    <TableCell>{getStatusBadge(vendor.level)}</TableCell>
                    <TableCell>
                      <div className="font-medium">{vendor.totalRevenue.toLocaleString()} ৳</div>
                      <div className="text-sm text-green-600">+{vendor.commissionsEarned.toLocaleString()} ৳ commission</div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{vendor.totalTransactions}</div>
                      <div className="text-sm text-gray-500">Last: {vendor.lastActive}</div>
                    </TableCell>
                    <TableCell>{getStatusBadge(vendor.status)}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <Eye className="h-3 w-3 mr-1" />
                          View
                        </Button>
                        <Button variant="outline" size="sm">
                          <Edit3 className="h-3 w-3 mr-1" />
                          Edit
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (activeTab === 'rewards') {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">Rewards Management</h2>
            <p className="text-gray-500">Manage customer rewards and loyalty programs</p>
          </div>
          <Button className="bg-blue-600 hover:bg-blue-700 text-white shadow-sm">
            <Plus className="h-4 w-4 mr-2" />
            Add New Reward
          </Button>
        </div>

        {/* Rewards Statistics */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Rewards</CardTitle>
              <Gift className="h-5 w-5 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{rewards.length}</div>
              <p className="text-xs text-green-600 mt-1">
                +3 new this month
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Active Rewards</CardTitle>
              <Star className="h-5 w-5 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{rewards.filter(r => r.status === 'Active').length}</div>
              <p className="text-xs text-gray-500 mt-1">
                Currently available
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total Claims</CardTitle>
              <Coins className="h-5 w-5 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{rewards.reduce((sum, r) => sum + r.claimed, 0)}</div>
              <p className="text-xs text-green-600 mt-1">
                +125 this week
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Expired Rewards</CardTitle>
              <AlertTriangle className="h-5 w-5 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{rewards.filter(r => r.status === 'Expired').length}</div>
              <p className="text-xs text-orange-600 mt-1">
                Need review
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Rewards Table */}
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle>All Rewards</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Reward Details</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Points Required</TableHead>
                  <TableHead>Claims</TableHead>
                  <TableHead>Valid Until</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rewards.map((reward) => (
                  <TableRow key={reward.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div>
                        <div className="font-medium">{reward.title}</div>
                        <div className="text-sm text-gray-500">{reward.description}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{reward.category}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <Coins className="h-4 w-4 mr-1 text-yellow-500" />
                        {reward.pointsRequired}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{reward.claimed}/{reward.maxClaims}</div>
                        <div className="text-sm text-gray-500">
                          {Math.round((reward.claimed/reward.maxClaims)*100)}% claimed
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">{reward.validUntil}</div>
                    </TableCell>
                    <TableCell>{getStatusBadge(reward.status)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" size="sm">
                          <Edit3 className="h-3 w-3 mr-1" />
                          Edit
                        </Button>
                        <Button variant="outline" size="sm">
                          <Eye className="h-3 w-3 mr-1" />
                          View
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (activeTab === 'settings') {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900">Settings</h2>
          <p className="text-gray-500">Configure system settings and preferences</p>
        </div>

        <div className="grid gap-6">
          <Card className="bg-white shadow-sm">
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <p className="text-sm text-gray-500">Configure basic system settings</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Dark Mode</Label>
                  <div className="text-sm text-gray-500">
                    Toggle dark mode for the admin interface
                  </div>
                </div>
                <Switch
                  checked={isDarkMode}
                  onCheckedChange={setIsDarkMode}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Email Notifications</Label>
                  <div className="text-sm text-gray-500">
                    Receive email notifications for important events
                  </div>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Auto-update Rates</Label>
                  <div className="text-sm text-gray-500">
                    Automatically update exchange rates every hour
                  </div>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm">
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <p className="text-sm text-gray-500">Manage security and authentication</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Two-Factor Authentication</Label>
                  <div className="text-sm text-gray-500">
                    Add an extra layer of security to your account
                  </div>
                </div>
                <Switch />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Session Timeout</Label>
                  <div className="text-sm text-gray-500">
                    Automatically logout after period of inactivity
                  </div>
                </div>
                <Select defaultValue="30">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 minutes</SelectItem>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="60">1 hour</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm">
            <CardHeader>
              <CardTitle>System Information</CardTitle>
              <p className="text-sm text-gray-500">Current system status and information</p>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label className="text-sm font-medium text-gray-500">Version</Label>
                  <div className="text-base">ExchangeWise v2.1.0</div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Last Updated</Label>
                  <div className="text-base">August 30, 2024</div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">Database Status</Label>
                  <div className="text-base text-green-600">Connected</div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">API Status</Label>
                  <div className="text-base text-green-600">Operational</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Fallback for any unhandled tabs
  return (
    <div className="flex items-center justify-center h-64">
      <div className="text-center">
        <h3 className="text-lg font-medium text-gray-900 mb-2">
          {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Section
        </h3>
        <p className="text-gray-500">
          This section is under development.
        </p>
      </div>
    </div>
  );
}