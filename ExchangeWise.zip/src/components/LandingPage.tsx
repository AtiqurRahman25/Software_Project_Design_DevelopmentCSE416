import { useState } from 'react';
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { toast } from "sonner@2.0.3";
import exchangeWiseLogo from 'figma:asset/8c7dbe677d8cc3b303c1a78ccbde0c1ca9d21bb9.png';
import { 
  ArrowRight, 
  Shield, 
  Globe, 
  Clock, 
  TrendingUp, 
  Users, 
  Star,
  CheckCircle,
  Mail,
  Phone,
  MapPin,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  Play,
  Award,
  Lock,
  Zap,
  CreditCard,
  ChevronDown,
  User,
  Building,
  Settings
} from "lucide-react";

interface LandingPageProps {
  onGetStarted: () => void;
  onUserLogin: () => void;
  onVendorLogin: () => void;
  onAdminLogin: () => void;
}

export function LandingPage({ onGetStarted, onUserLogin, onVendorLogin, onAdminLogin }: LandingPageProps) {
  const [email, setEmail] = useState('');
  const [isSubscribing, setIsSubscribing] = useState(false);

  const handleEmailSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast.error("Please enter your email address");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast.error("Please enter a valid email address");
      return;
    }

    setIsSubscribing(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    toast.success("Successfully subscribed to our newsletter!");
    setEmail('');
    setIsSubscribing(false);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation Header */}
      <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-gray-100 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <img 
                src={exchangeWiseLogo} 
                alt="ExchangeWise Logo" 
                className="w-8 h-8 object-contain"
              />
              <span className="ml-3 font-bold text-xl text-gray-900">ExchangeWise</span>
            </div>

            {/* Navigation Links */}
            <nav className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-gray-600 hover:text-emerald-600 transition-colors">Features</a>
              <a href="#how-it-works" className="text-gray-600 hover:text-emerald-600 transition-colors">How it Works</a>
              <a href="#rates" className="text-gray-600 hover:text-emerald-600 transition-colors">Rates</a>
              <a href="#contact" className="text-gray-600 hover:text-emerald-600 transition-colors">Contact</a>
            </nav>

            {/* Auth Buttons */}
            <div className="flex items-center space-x-3">
              <div className="hidden md:flex items-center space-x-3">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="text-gray-600 hover:text-emerald-600">
                      Login
                      <ChevronDown className="ml-1 h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <DropdownMenuItem onClick={onUserLogin} className="cursor-pointer">
                      <User className="mr-2 h-4 w-4" />
                      User Login
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={onVendorLogin} className="cursor-pointer">
                      <Building className="mr-2 h-4 w-4" />
                      Vendor Login
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={onAdminLogin} className="cursor-pointer">
                      <Settings className="mr-2 h-4 w-4" />
                      Admin Login
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              
              {/* Mobile Login Dropdown */}
              <div className="md:hidden">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="text-gray-600 hover:text-emerald-600">
                      <User className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <DropdownMenuItem onClick={onUserLogin} className="cursor-pointer">
                      <User className="mr-2 h-4 w-4" />
                      User Login
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={onVendorLogin} className="cursor-pointer">
                      <Building className="mr-2 h-4 w-4" />
                      Vendor Login
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={onAdminLogin} className="cursor-pointer">
                      <Settings className="mr-2 h-4 w-4" />
                      Admin Login
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              
              <Button onClick={onGetStarted} className="bg-emerald-600 hover:bg-emerald-700 text-white">
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-emerald-50 via-blue-50 to-teal-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-emerald-100 text-emerald-800 hover:bg-emerald-100">
                Trusted by 50,000+ Users
              </Badge>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                Currency Exchange
                <span className="text-emerald-600"> Made Simple</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Get the best exchange rates with instant transfers. Secure, fast, and transparent currency exchange for individuals and businesses worldwide.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-12">
                <Button onClick={onGetStarted} size="lg" className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4">
                  Start Exchanging Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button variant="outline" size="lg" className="border-gray-300 hover:bg-gray-50 px-8 py-4">
                  <Play className="mr-2 h-5 w-5" />
                  Watch Demo
                </Button>
              </div>

              {/* Trust Indicators */}
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="font-bold text-2xl text-gray-900">50K+</div>
                  <div className="text-sm text-gray-600">Happy Customers</div>
                </div>
                <div>
                  <div className="font-bold text-2xl text-gray-900">$2.5B+</div>
                  <div className="text-sm text-gray-600">Exchanged</div>
                </div>
                <div>
                  <div className="font-bold text-2xl text-gray-900">180+</div>
                  <div className="text-sm text-gray-600">Countries</div>
                </div>
              </div>
            </div>

            <div className="relative">
              {/* Live Currency Exchange Display */}
              <div className="relative z-10 bg-white rounded-2xl shadow-2xl p-8 border border-gray-100">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Live Exchange Rates</h3>
                  <p className="text-gray-600">Real-time currency conversion</p>
                  <div className="flex items-center justify-center mt-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-2"></div>
                    <span className="text-sm text-green-600 font-medium">Live</span>
                  </div>
                </div>
                
                {/* Featured Exchange Rate */}
                <div className="bg-gradient-to-r from-emerald-500 to-blue-500 rounded-xl p-6 text-white mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                        <span className="font-bold text-lg">$</span>
                      </div>
                      <div>
                        <div className="font-bold text-lg">USD</div>
                        <div className="text-emerald-100 text-sm">US Dollar</div>
                      </div>
                    </div>
                    <ArrowRight className="h-6 w-6 mx-4" />
                    <div className="flex items-center space-x-3">
                      <div>
                        <div className="font-bold text-lg">BDT</div>
                        <div className="text-emerald-100 text-sm">Bangladeshi Taka</div>
                      </div>
                      <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                        <span className="font-bold text-lg">৳</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold mb-2">119.85</div>
                    <div className="flex items-center justify-center space-x-2">
                      <TrendingUp className="h-4 w-4 text-green-300" />
                      <span className="text-green-300 font-medium">+0.25% today</span>
                    </div>
                  </div>
                </div>

                {/* Quick Exchange Grid */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {[
                    { from: "EUR", to: "BDT", rate: "130.45", flag: "€", change: "+0.18" },
                    { from: "GBP", to: "BDT", rate: "151.20", flag: "£", change: "-0.12" },
                    { from: "JPY", to: "BDT", rate: "0.80", flag: "¥", change: "+0.08" },
                    { from: "AUD", to: "BDT", rate: "79.35", flag: "A$", change: "+0.15" }
                  ].map((rate, index) => (
                    <div key={index} className="bg-gray-50 p-4 rounded-lg border border-gray-100 hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-lg">{rate.flag}</span>
                          <span className="font-medium">{rate.from}</span>
                        </div>
                        <ArrowRight className="h-3 w-3 text-gray-400" />
                        <span className="font-medium">BDT</span>
                      </div>
                      <div className="font-bold text-lg text-gray-900">{rate.rate}</div>
                      <div className={`text-sm font-medium ${rate.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                        {rate.change.startsWith('+') ? '+' : ''}{rate.change}%
                      </div>
                    </div>
                  ))}
                </div>

                {/* Last Updated */}
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-2 text-gray-500">
                    <Clock className="h-4 w-4" />
                    <span className="text-sm">Last updated: 2 minutes ago</span>
                  </div>
                </div>
              </div>

              {/* Floating Cards */}
              <div className="absolute -top-4 -left-4 bg-white p-4 rounded-lg shadow-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
                    <TrendingUp className="h-4 w-4 text-emerald-600" />
                  </div>
                  <div>
                    <div className="font-medium text-sm">Live Rates</div>
                    <div className="text-xs text-gray-500">Updated every minute</div>
                  </div>
                </div>
              </div>
              <div className="absolute -bottom-4 -right-4 bg-white p-4 rounded-lg shadow-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <Shield className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <div className="font-medium text-sm">Secure</div>
                    <div className="text-xs text-gray-500">Bank-level security</div>
                  </div>
                </div>
              </div>
              
              {/* Additional Floating Rate Card */}
              <div className="absolute top-1/2 -right-6 bg-gradient-to-r from-purple-500 to-pink-500 text-white p-3 rounded-lg shadow-lg transform -translate-y-1/2">
                <div className="text-center">
                  <div className="font-bold text-sm">Best Rate</div>
                  <div className="text-xs opacity-90">Save up to 3%</div>
                </div>
              </div>
              
              {/* Currency Flow Animation */}
              <div className="absolute top-1/4 -left-8 bg-gradient-to-r from-green-500 to-emerald-500 text-white p-3 rounded-lg shadow-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-white/20 rounded-full animate-pulse"></div>
                  <div className="text-xs font-medium">24/7 Trading</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose ExchangeWise?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We provide the most competitive rates, fastest transfers, and highest security standards in the industry.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <TrendingUp className="h-8 w-8 text-emerald-600" />,
                title: "Best Exchange Rates",
                description: "Get competitive rates with real-time market pricing and low fees."
              },
              {
                icon: <Zap className="h-8 w-8 text-blue-600" />,
                title: "Instant Transfers",
                description: "Transfer money instantly with our advanced processing technology."
              },
              {
                icon: <Shield className="h-8 w-8 text-purple-600" />,
                title: "Bank-Level Security",
                description: "Your money is protected with enterprise-grade security measures."
              },
              {
                icon: <Globe className="h-8 w-8 text-orange-600" />,
                title: "Global Reach",
                description: "Send money to over 180 countries with local support everywhere."
              },
              {
                icon: <Clock className="h-8 w-8 text-red-600" />,
                title: "24/7 Support",
                description: "Get help anytime with our round-the-clock customer support team."
              },
              {
                icon: <Award className="h-8 w-8 text-yellow-600" />,
                title: "Award Winning",
                description: "Recognized as the best currency exchange platform of 2024."
              }
            ].map((feature, index) => (
              <Card key={index} className="bg-white hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <div className="mb-4">{feature.icon}</div>
                  <CardTitle className="text-xl font-semibold">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-xl text-gray-600">
              Exchange currency in three simple steps
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: "1",
                title: "Create Account",
                description: "Sign up with your email and verify your identity in minutes."
              },
              {
                step: "2",
                title: "Choose Currencies",
                description: "Select the currencies you want to exchange and see live rates."
              },
              {
                step: "3",
                title: "Complete Transfer",
                description: "Confirm your transaction and receive your money instantly."
              }
            ].map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-emerald-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">
                  {step.step}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Live Rates Section */}
      <section id="rates" className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Live Exchange Rates
            </h2>
            <p className="text-xl text-gray-600">
              Real-time rates updated every minute
            </p>
          </div>

          <Card className="max-w-4xl mx-auto">
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { from: "USD", to: "BDT", rate: "119.85", change: "+0.25%" },
                  { from: "EUR", to: "BDT", rate: "130.45", change: "+0.18%" },
                  { from: "GBP", to: "BDT", rate: "151.20", change: "-0.12%" },
                  { from: "JPY", to: "BDT", rate: "0.80", change: "+0.08%" }
                ].map((rate, index) => (
                  <div key={index} className="text-center p-4 border border-gray-100 rounded-lg">
                    <div className="flex items-center justify-center space-x-2 mb-2">
                      <span className="px-2 py-1 bg-blue-50 text-blue-700 rounded text-sm font-medium">
                        {rate.from}
                      </span>
                      <ArrowRight className="h-4 w-4 text-gray-400" />
                      <span className="px-2 py-1 bg-emerald-50 text-emerald-700 rounded text-sm font-medium">
                        {rate.to}
                      </span>
                    </div>
                    <div className="font-bold text-xl text-gray-900 mb-1">{rate.rate}</div>
                    <div className={`text-sm ${rate.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                      {rate.change}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Newsletter Signup Section */}
      <section className="py-20 bg-emerald-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Stay Updated with Market Trends
          </h2>
          <p className="text-xl text-emerald-100 mb-8 max-w-2xl mx-auto">
            Get the latest exchange rates, market insights, and exclusive offers delivered to your inbox.
          </p>
          
          <form onSubmit={handleEmailSignup} className="max-w-md mx-auto">
            <div className="flex gap-2">
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                className="bg-white border-0 text-gray-900 flex-1"
                disabled={isSubscribing}
              />
              <Button
                type="submit"
                disabled={isSubscribing}
                className="bg-white text-emerald-600 hover:bg-gray-100 px-6"
              >
                {isSubscribing ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-emerald-600"></div>
                ) : (
                  "Subscribe"
                )}
              </Button>
            </div>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company Info */}
            <div>
              <div className="flex items-center mb-6">
                <img 
                  src={exchangeWiseLogo} 
                  alt="ExchangeWise Logo" 
                  className="w-8 h-8 object-contain invert"
                />
                <span className="ml-3 font-bold text-xl">ExchangeWise</span>
              </div>
              <p className="text-gray-400 mb-6">
                The world's most trusted currency exchange platform, serving customers in over 180 countries.
              </p>
              <div className="flex space-x-4">
                <Facebook className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
                <Twitter className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
                <Instagram className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
                <Linkedin className="h-5 w-5 text-gray-400 hover:text-white cursor-pointer" />
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="font-semibold text-lg mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">About Us</a></li>
                <li><a href="#" className="hover:text-white">Exchange Rates</a></li>
                <li><a href="#" className="hover:text-white">How It Works</a></li>
                <li><a href="#" className="hover:text-white">Help Center</a></li>
              </ul>
            </div>

            {/* Services */}
            <div>
              <h3 className="font-semibold text-lg mb-4">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Money Transfer</a></li>
                <li><a href="#" className="hover:text-white">Currency Exchange</a></li>
                <li><a href="#" className="hover:text-white">Business Solutions</a></li>
                <li><a href="#" className="hover:text-white">API Integration</a></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h3 className="font-semibold text-lg mb-4">Contact Us</h3>
              <div className="space-y-3 text-gray-400">
                <div className="flex items-center">
                  <Mail className="h-4 w-4 mr-2" />
                  support@exchangewise.com
                </div>
                <div className="flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  +1 (555) 123-4567
                </div>
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-2" />
                  New York, USA
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 mt-12">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="text-gray-400 mb-4 md:mb-0">
                © 2024 ExchangeWise. All rights reserved.
              </div>
              <div className="flex space-x-6 text-gray-400">
                <a href="#" className="hover:text-white">Privacy Policy</a>
                <a href="#" className="hover:text-white">Terms of Service</a>
                <a href="#" className="hover:text-white">Security</a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}