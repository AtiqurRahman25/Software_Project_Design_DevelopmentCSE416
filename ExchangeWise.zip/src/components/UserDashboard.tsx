import { useState } from 'react';
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Progress } from "./ui/progress";
import { toast } from "sonner@2.0.3";
import exchangeWiseLogo from 'figma:asset/8c7dbe677d8cc3b303c1a78ccbde0c1ca9d21bb9.png';
import { 
  ArrowUpDown, 
  TrendingUp, 
  Clock, 
  CheckCircle,
  Plus,
  History,
  CreditCard,
  User,
  Settings,
  LogOut,
  Bell,
  Gift,
  Star,
  Coins,
  Globe,
  Shield,
  Calculator,
  Eye,
  Download
} from "lucide-react";

interface UserDashboardProps {
  onLogout: () => void;
}

interface Transaction {
  id: string;
  date: string;
  from: string;
  to: string;
  amount: number;
  convertedAmount: number;
  rate: number;
  status: 'Completed' | 'Pending' | 'Failed';
  fee: number;
}

interface Reward {
  id: string;
  title: string;
  points: number;
  description: string;
  claimed: boolean;
}

const mockTransactions: Transaction[] = [
  {
    id: 'TXN-001',
    date: '2024-08-21',
    from: 'USD',
    to: 'BDT',
    amount: 500,
    convertedAmount: 59925,
    rate: 119.85,
    status: 'Completed',
    fee: 2.5
  },
  {
    id: 'TXN-002',
    date: '2024-08-20',
    from: 'EUR',
    to: 'BDT',
    amount: 300,
    convertedAmount: 39135,
    rate: 130.45,
    status: 'Completed',
    fee: 3.0
  },
  {
    id: 'TXN-003',
    date: '2024-08-19',
    from: 'GBP',
    to: 'BDT',
    amount: 200,
    convertedAmount: 30240,
    rate: 151.20,
    status: 'Pending',
    fee: 2.0
  }
];

const mockRewards: Reward[] = [
  {
    id: '1',
    title: 'First Exchange Bonus',
    points: 100,
    description: 'Complete your first exchange',
    claimed: true
  },
  {
    id: '2',
    title: '5% Cashback',
    points: 500,
    description: 'Exchange over $1000',
    claimed: false
  },
  {
    id: '3',
    title: 'Loyalty Reward',
    points: 250,
    description: '5 successful exchanges',
    claimed: false
  }
];

const currencies = [
  { code: "USD", name: "US Dollar", rate: 119.85 },
  { code: "EUR", name: "Euro", rate: 130.45 },
  { code: "GBP", name: "British Pound", rate: 151.20 },
  { code: "JPY", name: "Japanese Yen", rate: 0.80 },
  { code: "AUD", name: "Australian Dollar", rate: 79.35 },
  { code: "BDT", name: "Bangladeshi Taka", rate: 1.00 }
];

export function UserDashboard({ onLogout }: UserDashboardProps) {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('BDT');
  const [amount, setAmount] = useState('');
  const [convertedAmount, setConvertedAmount] = useState(0);

  const sidebarItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Globe },
    { id: 'exchange', label: 'Exchange', icon: ArrowUpDown },
    { id: 'history', label: 'History', icon: History },
    { id: 'rewards', label: 'Rewards', icon: Gift },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const userStats = {
    totalExchanged: 129300,
    rewardPoints: 850,
    completedTransactions: 15,
    memberSince: 'March 2024'
  };

  const calculateConversion = () => {
    const fromRate = currencies.find(c => c.code === fromCurrency)?.rate || 1;
    const toRate = currencies.find(c => c.code === toCurrency)?.rate || 1;
    const amountNum = parseFloat(amount) || 0;
    
    let result;
    if (fromCurrency === 'BDT') {
      result = amountNum / toRate;
    } else if (toCurrency === 'BDT') {
      result = amountNum * fromRate;
    } else {
      // Convert via BDT
      const bdtAmount = amountNum * fromRate;
      result = bdtAmount / toRate;
    }
    
    setConvertedAmount(result);
  };

  const handleExchange = () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }
    
    if (fromCurrency === toCurrency) {
      toast.error("Please select different currencies");
      return;
    }

    toast.success("Exchange initiated! You will receive a confirmation shortly.");
    setAmount('');
    setConvertedAmount(0);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Completed':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100"><CheckCircle className="w-3 h-3 mr-1" />Completed</Badge>;
      case 'Pending':
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'Failed':
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Failed</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-emerald-600 to-blue-600 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2">Welcome back, John!</h2>
            <p className="text-emerald-100">Ready to exchange currencies at the best rates?</p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold">{userStats.rewardPoints}</div>
            <div className="text-emerald-100">Reward Points</div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-emerald-100 rounded-lg">
                <ArrowUpDown className="h-5 w-5 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Total Exchanged</p>
                <p className="font-bold text-lg">{userStats.totalExchanged.toLocaleString()} BDT</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <CheckCircle className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Completed</p>
                <p className="font-bold text-lg">{userStats.completedTransactions}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Gift className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Reward Points</p>
                <p className="font-bold text-lg">{userStats.rewardPoints}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Star className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Member Since</p>
                <p className="font-bold text-lg">{userStats.memberSince}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Transactions */}
      <Card className="bg-white shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Recent Transactions</span>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setActiveTab('history')}
            >
              View All
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {mockTransactions.slice(0, 3).map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-white rounded-lg shadow-sm">
                    <ArrowUpDown className="h-4 w-4 text-gray-600" />
                  </div>
                  <div>
                    <div className="font-medium">
                      {transaction.amount} {transaction.from} → {transaction.convertedAmount.toLocaleString()} {transaction.to}
                    </div>
                    <div className="text-sm text-gray-500">{transaction.date}</div>
                  </div>
                </div>
                <div className="text-right">
                  {getStatusBadge(transaction.status)}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderExchange = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900">Currency Exchange</h2>
          <p className="text-gray-500">Exchange currencies at competitive rates</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Exchange Form */}
        <Card className="lg:col-span-2 bg-white shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calculator className="h-5 w-5 mr-2 text-emerald-600" />
              Exchange Calculator
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>From Currency</Label>
                <Select value={fromCurrency} onValueChange={setFromCurrency}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map((currency) => (
                      <SelectItem key={currency.code} value={currency.code}>
                        {currency.code} - {currency.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>To Currency</Label>
                <Select value={toCurrency} onValueChange={setToCurrency}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map((currency) => (
                      <SelectItem key={currency.code} value={currency.code}>
                        {currency.code} - {currency.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Amount</Label>
                <Input
                  type="number"
                  value={amount}
                  onChange={(e) => {
                    setAmount(e.target.value);
                    calculateConversion();
                  }}
                  placeholder="Enter amount"
                  onBlur={calculateConversion}
                />
              </div>

              <div className="space-y-2">
                <Label>You'll Receive</Label>
                <Input
                  type="number"
                  value={convertedAmount.toFixed(2)}
                  readOnly
                  className="bg-gray-50"
                />
              </div>
            </div>

            <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
              <div className="flex justify-between items-center text-sm">
                <span>Exchange Rate:</span>
                <span className="font-medium">1 {fromCurrency} = {currencies.find(c => c.code === fromCurrency)?.rate} BDT</span>
              </div>
              <div className="flex justify-between items-center text-sm mt-1">
                <span>Fee:</span>
                <span className="font-medium">2.5 BDT</span>
              </div>
            </div>

            <Button onClick={handleExchange} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3">
              <ArrowUpDown className="h-4 w-4 mr-2" />
              Exchange Now
            </Button>
          </CardContent>
        </Card>

        {/* Live Rates */}
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="h-5 w-5 mr-2 text-blue-600" />
              Live Rates
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {currencies.filter(c => c.code !== 'BDT').map((currency) => (
                <div key={currency.code} className="flex justify-between items-center p-3 border border-gray-100 rounded-lg">
                  <div>
                    <div className="font-medium">{currency.code}</div>
                    <div className="text-sm text-gray-500">{currency.name}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold">{currency.rate}</div>
                    <div className="text-xs text-green-600">+0.25%</div>
                  </div>
                </div>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-4 text-center">
              Rates updated every minute
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderHistory = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900">Transaction History</h2>
          <p className="text-gray-500">View all your exchange transactions</p>
        </div>
        <Button variant="outline" className="flex items-center">
          <Download className="h-4 w-4 mr-2" />
          Export
        </Button>
      </div>

      <Card className="bg-white shadow-sm">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Transaction ID</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Exchange</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Rate</TableHead>
                <TableHead>Fee</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockTransactions.map((transaction) => (
                <TableRow key={transaction.id} className="hover:bg-gray-50">
                  <TableCell className="font-mono text-sm">{transaction.id}</TableCell>
                  <TableCell>{transaction.date}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline">{transaction.from}</Badge>
                      <ArrowUpDown className="h-3 w-3" />
                      <Badge variant="outline">{transaction.to}</Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <div>{transaction.amount} {transaction.from}</div>
                      <div className="text-sm text-gray-500">
                        = {transaction.convertedAmount.toLocaleString()} {transaction.to}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="font-mono">{transaction.rate}</TableCell>
                  <TableCell>{transaction.fee} BDT</TableCell>
                  <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm">
                      <Eye className="h-3 w-3 mr-1" />
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );

  const renderRewards = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900">Reward Points</h2>
          <p className="text-gray-500">Earn points with every exchange and redeem rewards</p>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold text-emerald-600">{userStats.rewardPoints}</div>
          <div className="text-sm text-gray-500">Available Points</div>
        </div>
      </div>

      {/* Progress to Next Reward */}
      <Card className="bg-gradient-to-r from-emerald-100 to-blue-100">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-semibold text-gray-900">Progress to VIP Status</h3>
              <p className="text-sm text-gray-600">Reach 1000 points to unlock VIP benefits</p>
            </div>
            <div className="text-2xl font-bold text-emerald-600">
              {Math.round((userStats.rewardPoints / 1000) * 100)}%
            </div>
          </div>
          <Progress value={(userStats.rewardPoints / 1000) * 100} className="h-3" />
          <p className="text-sm text-gray-600 mt-2">
            {1000 - userStats.rewardPoints} points remaining
          </p>
        </CardContent>
      </Card>

      {/* Available Rewards */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {mockRewards.map((reward) => (
          <Card key={reward.id} className={`${reward.claimed ? 'bg-gray-50' : 'bg-white'} shadow-sm hover:shadow-md transition-shadow`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className={`p-2 rounded-lg ${reward.claimed ? 'bg-gray-200' : 'bg-emerald-100'}`}>
                  <Gift className={`h-5 w-5 ${reward.claimed ? 'text-gray-500' : 'text-emerald-600'}`} />
                </div>
                <div className="flex items-center space-x-1">
                  <Coins className={`h-4 w-4 ${reward.claimed ? 'text-gray-500' : 'text-orange-500'}`} />
                  <span className={`font-medium ${reward.claimed ? 'text-gray-500' : 'text-orange-600'}`}>
                    {reward.points}
                  </span>
                </div>
              </div>
              <h3 className={`font-semibold mb-2 ${reward.claimed ? 'text-gray-500' : 'text-gray-900'}`}>
                {reward.title}
              </h3>
              <p className={`text-sm mb-4 ${reward.claimed ? 'text-gray-400' : 'text-gray-600'}`}>
                {reward.description}
              </p>
              <Button
                variant={reward.claimed ? "outline" : "default"}
                size="sm"
                className="w-full"
                disabled={reward.claimed || userStats.rewardPoints < reward.points}
              >
                {reward.claimed ? 'Claimed' : 
                 userStats.rewardPoints < reward.points ? 'Not Enough Points' : 'Claim Reward'}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold text-gray-900">Account Settings</h2>
        <p className="text-gray-500">Manage your account preferences and security</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Profile Settings */}
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle>Profile Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Full Name</Label>
              <Input defaultValue="John Doe" />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input defaultValue="john.doe@email.com" />
            </div>
            <div className="space-y-2">
              <Label>Phone</Label>
              <Input defaultValue="+1 (555) 123-4567" />
            </div>
            <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
              Update Profile
            </Button>
          </CardContent>
        </Card>

        {/* Security Settings */}
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle>Security</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Current Password</Label>
              <Input type="password" placeholder="Enter current password" />
            </div>
            <div className="space-y-2">
              <Label>New Password</Label>
              <Input type="password" placeholder="Enter new password" />
            </div>
            <div className="space-y-2">
              <Label>Confirm New Password</Label>
              <Input type="password" placeholder="Confirm new password" />
            </div>
            <Button className="w-full bg-blue-600 hover:bg-blue-700">
              Change Password
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Preferences */}
      <Card className="bg-white shadow-sm">
        <CardHeader>
          <CardTitle>Preferences</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Email Notifications</div>
                <div className="text-sm text-gray-500">Receive updates about your transactions</div>
              </div>
              <Button variant="outline">Manage</Button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">SMS Notifications</div>
                <div className="text-sm text-gray-500">Get SMS alerts for important activities</div>
              </div>
              <Button variant="outline">Manage</Button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Two-Factor Authentication</div>
                <div className="text-sm text-gray-500">Add an extra layer of security</div>
              </div>
              <Button variant="outline">Enable</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return renderDashboard();
      case 'exchange': return renderExchange();
      case 'history': return renderHistory();
      case 'rewards': return renderRewards();
      case 'settings': return renderSettings();
      default: return renderDashboard();
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-sm border-r border-gray-200">
        {/* Logo */}
        <div className="flex items-center h-16 px-6 border-b border-gray-200">
          <div className="flex items-center">
            <img 
              src={exchangeWiseLogo} 
              alt="ExchangeWise Logo" 
              className="w-8 h-8 object-contain"
            />
            <span className="ml-3 font-semibold text-gray-900">ExchangeWise</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="mt-6 px-4">
          <div className="space-y-2">
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 ${
                    activeTab === item.id
                      ? 'bg-emerald-50 text-emerald-700 shadow-sm'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`}
                >
                  <Icon className="h-5 w-5 mr-3" />
                  {item.label}
                </button>
              );
            })}
          </div>
        </nav>

        {/* User Profile & Logout */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200">
          <div className="mb-3 px-4 py-2 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <Avatar className="h-8 w-8">
                <AvatarImage src="/placeholder-avatar.jpg" />
                <AvatarFallback className="bg-emerald-600 text-white">JD</AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <div className="text-sm font-medium">John Doe</div>
                <div className="text-xs text-gray-500">Personal Account</div>
              </div>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="w-full flex items-center px-4 py-3 text-sm font-medium text-gray-600 hover:bg-gray-50 hover:text-gray-900 rounded-lg transition-all duration-200"
          >
            <LogOut className="h-5 w-5 mr-3" />
            Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="pl-64">
        {/* Top Navbar */}
        <header className="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-6 shadow-sm">
          <div>
            <h1 className="text-xl font-semibold text-gray-900">
              {sidebarItems.find(item => item.id === activeTab)?.label || 'Dashboard'}
            </h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                2
              </span>
            </Button>
            <div className="flex items-center space-x-2">
              <div className="text-sm">
                <div className="flex items-center space-x-1 text-emerald-600">
                  <Coins className="h-4 w-4" />
                  <span className="font-medium">{userStats.rewardPoints}</span>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}