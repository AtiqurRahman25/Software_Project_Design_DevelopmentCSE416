import { useState } from 'react';
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Progress } from "./ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { toast } from "sonner@2.0.3";
import exchangeWiseLogo from 'figma:asset/8c7dbe677d8cc3b303c1a78ccbde0c1ca9d21bb9.png';
import { 
  Building, 
  TrendingUp, 
  Users, 
  DollarSign,
  Clock,
  CheckCircle,
  AlertCircle,
  BarChart3,
  Settings,
  LogOut,
  Bell,
  FileText,
  CreditCard,
  Eye,
  Filter,
  Download,
  Calendar,
  Globe,
  Target,
  Award,
  Wallet,
  ArrowUpDown,
  Activity
} from "lucide-react";

interface VendorDashboardProps {
  onLogout: () => void;
}

interface Transaction {
  id: string;
  date: string;
  customerId: string;
  from: string;
  to: string;
  amount: number;
  convertedAmount: number;
  commission: number;
  status: 'Completed' | 'Pending' | 'Failed';
}

interface Customer {
  id: string;
  name: string;
  email: string;
  totalTransactions: number;
  totalVolume: number;
  lastTransaction: string;
  status: 'Active' | 'Inactive';
}

const mockTransactions: Transaction[] = [
  {
    id: 'TXN-V-001',
    date: '2024-08-21',
    customerId: 'CUST-001',
    from: 'USD',
    to: 'BDT',
    amount: 1000,
    convertedAmount: 119850,
    commission: 150,
    status: 'Completed'
  },
  {
    id: 'TXN-V-002',
    date: '2024-08-21',
    customerId: 'CUST-002',
    from: 'EUR',
    to: 'BDT',
    amount: 750,
    convertedAmount: 97837.5,
    commission: 120,
    status: 'Completed'
  },
  {
    id: 'TXN-V-003',
    date: '2024-08-20',
    customerId: 'CUST-003',
    from: 'GBP',
    to: 'BDT',
    amount: 500,
    convertedAmount: 75600,
    commission: 95,
    status: 'Pending'
  },
  {
    id: 'TXN-V-004',
    date: '2024-08-20',
    customerId: 'CUST-001',
    from: 'USD',
    to: 'BDT',
    amount: 2000,
    convertedAmount: 239700,
    commission: 300,
    status: 'Completed'
  }
];

const mockCustomers: Customer[] = [
  {
    id: 'CUST-001',
    name: 'Sarah Johnson',
    email: 'sarah.j@email.com',
    totalTransactions: 15,
    totalVolume: 45000,
    lastTransaction: '2024-08-21',
    status: 'Active'
  },
  {
    id: 'CUST-002',
    name: 'Mike Chen',
    email: 'mike.chen@email.com',
    totalTransactions: 8,
    totalVolume: 22000,
    lastTransaction: '2024-08-21',
    status: 'Active'
  },
  {
    id: 'CUST-003',
    name: 'Emma Davis',
    email: 'emma.d@email.com',
    totalTransactions: 12,
    totalVolume: 38000,
    lastTransaction: '2024-08-20',
    status: 'Active'
  }
];

export function VendorDashboard({ onLogout }: VendorDashboardProps) {
  const [activeTab, setActiveTab] = useState('dashboard');

  const sidebarItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Building },
    { id: 'transactions', label: 'Transactions', icon: CreditCard },
    { id: 'customers', label: 'Customers', icon: Users },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'reports', label: 'Reports', icon: FileText },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const vendorStats = {
    totalRevenue: 125750,
    totalCommissions: 8950,
    activeCustomers: 34,
    completedTransactions: 142,
    monthlyGrowth: 12.5,
    avgTransactionSize: 1850,
    licenseId: 'VL-BD-2024-001',
    businessName: 'Global Exchange Solutions Ltd.'
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Completed':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100"><CheckCircle className="w-3 h-3 mr-1" />Completed</Badge>;
      case 'Pending':
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'Failed':
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100"><AlertCircle className="w-3 h-3 mr-1" />Failed</Badge>;
      case 'Active':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100"><CheckCircle className="w-3 h-3 mr-1" />Active</Badge>;
      case 'Inactive':
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100"><Clock className="w-3 h-3 mr-1" />Inactive</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Business Overview */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2">{vendorStats.businessName}</h2>
            <p className="text-blue-100">License ID: {vendorStats.licenseId}</p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold">{vendorStats.totalRevenue.toLocaleString()} BDT</div>
            <div className="text-blue-100">Monthly Revenue</div>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <DollarSign className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Total Commissions</p>
                <p className="font-bold text-lg">{vendorStats.totalCommissions.toLocaleString()} BDT</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Users className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Active Customers</p>
                <p className="font-bold text-lg">{vendorStats.activeCustomers}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <CreditCard className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Transactions</p>
                <p className="font-bold text-lg">{vendorStats.completedTransactions}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <TrendingUp className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Growth Rate</p>
                <p className="font-bold text-lg">+{vendorStats.monthlyGrowth}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Overview */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Monthly Performance */}
        <Card className="lg:col-span-2 bg-white shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Monthly Performance</span>
              <Button variant="outline" size="sm">
                <Calendar className="h-4 w-4 mr-2" />
                This Month
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Revenue Target</span>
                <span className="font-medium">85% Complete</span>
              </div>
              <Progress value={85} className="h-3" />
              
              <div className="grid grid-cols-2 gap-4 pt-4">
                <div>
                  <p className="text-sm text-gray-600">Avg. Transaction</p>
                  <p className="font-bold text-xl">{vendorStats.avgTransactionSize.toLocaleString()} BDT</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Success Rate</p>
                  <p className="font-bold text-xl">97.5%</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full bg-blue-600 hover:bg-blue-700 justify-start">
              <FileText className="h-4 w-4 mr-2" />
              Generate Report
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Download className="h-4 w-4 mr-2" />
              Export Transactions
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Users className="h-4 w-4 mr-2" />
              View Customers
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <Settings className="h-4 w-4 mr-2" />
              Account Settings
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Recent Transactions */}
      <Card className="bg-white shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Recent Transactions</span>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setActiveTab('transactions')}
            >
              View All
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {mockTransactions.slice(0, 5).map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-white rounded-lg shadow-sm">
                    <ArrowUpDown className="h-4 w-4 text-gray-600" />
                  </div>
                  <div>
                    <div className="font-medium">
                      {transaction.amount} {transaction.from} → {transaction.convertedAmount.toLocaleString()} {transaction.to}
                    </div>
                    <div className="text-sm text-gray-500">{transaction.customerId} • {transaction.date}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium text-green-600">+{transaction.commission} BDT</div>
                  {getStatusBadge(transaction.status)}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderTransactions = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900">Transaction Management</h2>
          <p className="text-gray-500">Monitor and manage all customer transactions</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" className="flex items-center">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button variant="outline" className="flex items-center">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Transaction Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="bg-white shadow-sm">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">
                {mockTransactions.filter(t => t.status === 'Completed').length}
              </div>
              <div className="text-sm text-gray-600">Completed Today</div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white shadow-sm">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">
                {mockTransactions.filter(t => t.status === 'Pending').length}
              </div>
              <div className="text-sm text-gray-600">Pending</div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {mockTransactions.reduce((sum, t) => sum + t.commission, 0).toLocaleString()} BDT
              </div>
              <div className="text-sm text-gray-600">Total Commission</div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {Math.round(mockTransactions.reduce((sum, t) => sum + t.amount, 0) / mockTransactions.length).toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Avg. Amount</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Transactions Table */}
      <Card className="bg-white shadow-sm">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Transaction ID</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Exchange</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Commission</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockTransactions.map((transaction) => (
                <TableRow key={transaction.id} className="hover:bg-gray-50">
                  <TableCell className="font-mono text-sm">{transaction.id}</TableCell>
                  <TableCell>{transaction.date}</TableCell>
                  <TableCell className="font-medium">{transaction.customerId}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline">{transaction.from}</Badge>
                      <ArrowUpDown className="h-3 w-3" />
                      <Badge variant="outline">{transaction.to}</Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{transaction.amount} {transaction.from}</div>
                      <div className="text-sm text-gray-500">
                        = {transaction.convertedAmount.toLocaleString()} {transaction.to}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium text-green-600">
                    +{transaction.commission} BDT
                  </TableCell>
                  <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm">
                      <Eye className="h-3 w-3 mr-1" />
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );

  const renderCustomers = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900">Customer Management</h2>
          <p className="text-gray-500">View and manage your customer relationships</p>
        </div>
      </div>

      {/* Customer Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="bg-white shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Users className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Total Customers</p>
                <p className="font-bold text-lg">{mockCustomers.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <Activity className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Active Today</p>
                <p className="font-bold text-lg">{mockCustomers.filter(c => c.status === 'Active').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Wallet className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Avg. Volume</p>
                <p className="font-bold text-lg">
                  {Math.round(mockCustomers.reduce((sum, c) => sum + c.totalVolume, 0) / mockCustomers.length).toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Target className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Retention Rate</p>
                <p className="font-bold text-lg">94%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Customers Table */}
      <Card className="bg-white shadow-sm">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Customer</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Transactions</TableHead>
                <TableHead>Total Volume</TableHead>
                <TableHead>Last Transaction</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockCustomers.map((customer) => (
                <TableRow key={customer.id} className="hover:bg-gray-50">
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-blue-100 text-blue-600">
                          {customer.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{customer.name}</div>
                        <div className="text-sm text-gray-500">{customer.id}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{customer.email}</TableCell>
                  <TableCell className="font-medium">{customer.totalTransactions}</TableCell>
                  <TableCell className="font-medium">{customer.totalVolume.toLocaleString()} BDT</TableCell>
                  <TableCell>{customer.lastTransaction}</TableCell>
                  <TableCell>{getStatusBadge(customer.status)}</TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm">
                      <Eye className="h-3 w-3 mr-1" />
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );

  const renderAnalytics = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold text-gray-900">Business Analytics</h2>
        <p className="text-gray-500">Insights and performance metrics for your business</p>
      </div>

      {/* Key Performance Indicators */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-r from-green-500 to-emerald-500 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100">Revenue Growth</p>
                <p className="text-3xl font-bold">+{vendorStats.monthlyGrowth}%</p>
                <p className="text-sm text-green-100">vs last month</p>
              </div>
              <TrendingUp className="h-12 w-12 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100">Customer Satisfaction</p>
                <p className="text-3xl font-bold">4.9/5</p>
                <p className="text-sm text-blue-100">Average rating</p>
              </div>
              <Award className="h-12 w-12 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100">Market Share</p>
                <p className="text-3xl font-bold">15.8%</p>
                <p className="text-sm text-purple-100">in your region</p>
              </div>
              <Globe className="h-12 w-12 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Charts Placeholder */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle>Revenue Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500">Revenue chart would be displayed here</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle>Customer Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <Activity className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500">Activity chart would be displayed here</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold text-gray-900">Vendor Settings</h2>
        <p className="text-gray-500">Manage your business profile and preferences</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Business Profile */}
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle>Business Profile</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Business Name</label>
              <input 
                className="w-full p-2 border border-gray-300 rounded-lg" 
                defaultValue={vendorStats.businessName} 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">License ID</label>
              <input 
                className="w-full p-2 border border-gray-300 rounded-lg bg-gray-50" 
                defaultValue={vendorStats.licenseId} 
                disabled 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Business Email</label>
              <input 
                className="w-full p-2 border border-gray-300 rounded-lg" 
                defaultValue="vendor@exchangewise.com" 
              />
            </div>
            <Button className="w-full bg-blue-600 hover:bg-blue-700">
              Update Profile
            </Button>
          </CardContent>
        </Card>

        {/* Commission Settings */}
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle>Commission Rates</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Standard Rate (%)</label>
              <input 
                className="w-full p-2 border border-gray-300 rounded-lg" 
                defaultValue="1.5" 
                type="number"
                step="0.1"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">VIP Customer Rate (%)</label>
              <input 
                className="w-full p-2 border border-gray-300 rounded-lg" 
                defaultValue="1.0" 
                type="number"
                step="0.1"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Minimum Transaction (BDT)</label>
              <input 
                className="w-full p-2 border border-gray-300 rounded-lg" 
                defaultValue="1000" 
                type="number"
              />
            </div>
            <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
              Update Rates
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Notification Preferences */}
      <Card className="bg-white shadow-sm">
        <CardHeader>
          <CardTitle>Notification Preferences</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Email Notifications</div>
                <div className="text-sm text-gray-500">Receive transaction alerts via email</div>
              </div>
              <Button variant="outline">Configure</Button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">SMS Alerts</div>
                <div className="text-sm text-gray-500">Get SMS for high-value transactions</div>
              </div>
              <Button variant="outline">Configure</Button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Daily Reports</div>
                <div className="text-sm text-gray-500">Automated daily business reports</div>
              </div>
              <Button variant="outline">Configure</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return renderDashboard();
      case 'transactions': return renderTransactions();
      case 'customers': return renderCustomers();
      case 'analytics': return renderAnalytics();
      case 'reports': return <div className="text-center py-20"><FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" /><p className="text-gray-500">Reports feature coming soon</p></div>;
      case 'settings': return renderSettings();
      default: return renderDashboard();
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-sm border-r border-gray-200">
        {/* Logo */}
        <div className="flex items-center h-16 px-6 border-b border-gray-200">
          <div className="flex items-center">
            <img 
              src={exchangeWiseLogo} 
              alt="ExchangeWise Logo" 
              className="w-8 h-8 object-contain"
            />
            <span className="ml-3 font-semibold text-gray-900">ExchangeWise</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="mt-6 px-4">
          <div className="space-y-2">
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 ${
                    activeTab === item.id
                      ? 'bg-blue-50 text-blue-700 shadow-sm'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`}
                >
                  <Icon className="h-5 w-5 mr-3" />
                  {item.label}
                </button>
              );
            })}
          </div>
        </nav>

        {/* Vendor Profile & Logout */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200">
          <div className="mb-3 px-4 py-2 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-blue-600 text-white">
                  <Building className="h-4 w-4" />
                </AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <div className="text-sm font-medium">Global Exchange</div>
                <div className="text-xs text-gray-500">Vendor Account</div>
              </div>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="w-full flex items-center px-4 py-3 text-sm font-medium text-gray-600 hover:bg-gray-50 hover:text-gray-900 rounded-lg transition-all duration-200"
          >
            <LogOut className="h-5 w-5 mr-3" />
            Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="pl-64">
        {/* Top Navbar */}
        <header className="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-6 shadow-sm">
          <div>
            <h1 className="text-xl font-semibold text-gray-900">
              {sidebarItems.find(item => item.id === activeTab)?.label || 'Dashboard'}
            </h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                3
              </span>
            </Button>
            <div className="text-sm">
              <div className="flex items-center space-x-1 text-blue-600">
                <Building className="h-4 w-4" />
                <span className="font-medium">{vendorStats.licenseId}</span>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}