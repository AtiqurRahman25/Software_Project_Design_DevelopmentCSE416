import { useState } from 'react';
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { toast } from "sonner@2.0.3";
import exchangeWiseLogo from 'figma:asset/8c7dbe677d8cc3b303c1a78ccbde0c1ca9d21bb9.png';
import { Eye, EyeOff, Lock, Mail, Building, ArrowLeft, FileText } from "lucide-react";

interface VendorLoginProps {
  onLogin: () => void;
  onBack: () => void;
}

interface LoginFormData {
  email: string;
  password: string;
}

export function VendorLogin({ onLogin, onBack }: VendorLoginProps) {
  const [formData, setFormData] = useState<LoginFormData>({
    email: '',
    password: ''
  });
  const [formErrors, setFormErrors] = useState<Partial<LoginFormData>>({});
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [businessName, setBusinessName] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');

  const handleInputChange = (field: keyof LoginFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (formErrors[field]) {
      setFormErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const validateForm = (): boolean => {
    const errors: Partial<LoginFormData> = {};

    if (!formData.email.trim()) {
      errors.email = 'Email is required';
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        errors.email = 'Please enter a valid email address';
      }
    }

    if (!formData.password.trim()) {
      errors.password = 'Password is required';
    } else if (formData.password.length < 8) {
      errors.password = 'Password must be at least 8 characters';
    }

    if (isSignUp) {
      if (!businessName.trim()) {
        toast.error("Please enter your business name");
        return false;
      }
      if (!licenseNumber.trim()) {
        toast.error("Please enter your license number");
        return false;
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error("Please fix the form errors before continuing.");
      return;
    }

    setIsLoading(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (isSignUp) {
        toast.success(`Welcome to ExchangeWise, ${businessName}! Your vendor account has been created and is under review.`);
      } else {
        toast.success("Welcome back! Redirecting to your vendor dashboard...");
      }
      
      setTimeout(() => {
        onLogin();
      }, 1000);
    } catch (error) {
      toast.error(`An error occurred during ${isSignUp ? 'registration' : 'sign in'}. Please try again.`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDemoLogin = () => {
    setFormData({
      email: 'vendor@exchangewise.com',
      password: 'vendor123'
    });
    setFormErrors({});
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <div className="mb-6">
          <Button 
            variant="ghost" 
            onClick={onBack}
            className="text-gray-600 hover:text-blue-600 p-0"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
        </div>

        {/* Logo and Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-white rounded-2xl mb-4 shadow-lg border border-gray-100">
            <img 
              src={exchangeWiseLogo} 
              alt="ExchangeWise Logo" 
              className="w-12 h-12 object-contain"
            />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            {isSignUp ? 'Join as Vendor' : 'Vendor Portal'}
          </h1>
          <p className="text-gray-600">
            {isSignUp 
              ? 'Register your business to become an authorized vendor' 
              : 'Access your vendor dashboard and tools'
            }
          </p>
        </div>

        {/* Login Card */}
        <Card className="bg-white shadow-xl border-0">
          <CardHeader className="space-y-1 pb-6">
            <CardTitle className="text-xl text-center flex items-center justify-center">
              <Building className="h-5 w-5 mr-2 text-blue-600" />
              {isSignUp ? 'Vendor Registration' : 'Vendor Login'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {isSignUp && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="businessName" className="text-sm font-medium text-gray-700">
                      Business Name
                    </Label>
                    <div className="relative">
                      <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="businessName"
                        type="text"
                        value={businessName}
                        onChange={(e) => setBusinessName(e.target.value)}
                        placeholder="Enter your business name"
                        className="pl-10 border-gray-300 focus:border-blue-500 h-11"
                        disabled={isLoading}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="licenseNumber" className="text-sm font-medium text-gray-700">
                      License Number
                    </Label>
                    <div className="relative">
                      <FileText className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="licenseNumber"
                        type="text"
                        value={licenseNumber}
                        onChange={(e) => setLicenseNumber(e.target.value.toUpperCase())}
                        placeholder="e.g., VL-BD-2024-001"
                        className="pl-10 border-gray-300 focus:border-blue-500 h-11"
                        disabled={isLoading}
                        maxLength={20}
                      />
                    </div>
                    <p className="text-xs text-gray-500">Your official business license number</p>
                  </div>
                </>
              )}

              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                  Business Email
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    placeholder="Enter your business email"
                    className={`pl-10 ${formErrors.email ? 'border-red-500 focus:border-red-500' : 'border-gray-300 focus:border-blue-500'} h-11`}
                    disabled={isLoading}
                  />
                </div>
                {formErrors.email && (
                  <p className="text-sm text-red-500">{formErrors.email}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium text-gray-700">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    placeholder="Enter your password"
                    className={`pl-10 pr-10 ${formErrors.password ? 'border-red-500 focus:border-red-500' : 'border-gray-300 focus:border-blue-500'} h-11`}
                    disabled={isLoading}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    disabled={isLoading}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {formErrors.password && (
                  <p className="text-sm text-red-500">{formErrors.password}</p>
                )}
                {isSignUp && (
                  <p className="text-xs text-gray-500">Minimum 8 characters required for vendor accounts</p>
                )}
              </div>

              {isSignUp && (
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-800 font-medium mb-1">
                    Vendor Requirements:
                  </p>
                  <ul className="text-xs text-blue-700 space-y-1">
                    <li>• Valid business license required</li>
                    <li>• Account subject to approval process</li>
                    <li>• Compliance verification needed</li>
                  </ul>
                </div>
              )}

              {!isSignUp && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <input
                      id="remember-me"
                      name="remember-me"
                      type="checkbox"
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-700">
                      Remember me
                    </label>
                  </div>
                  <button
                    type="button"
                    className="text-sm text-blue-600 hover:text-blue-500 font-medium"
                  >
                    Forgot password?
                  </button>
                </div>
              )}

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white h-11 font-medium shadow-lg hover:shadow-xl transition-all duration-200"
              >
                {isLoading ? (
                  <div className="flex items-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    {isSignUp ? 'Submitting Application...' : 'Signing in...'}
                  </div>
                ) : (
                  isSignUp ? 'Submit Application' : 'Access Dashboard'
                )}
              </Button>
            </form>

            {/* Toggle Sign Up/Sign In */}
            <div className="mt-6 text-center">
              <button
                type="button"
                onClick={() => {
                  setIsSignUp(!isSignUp);
                  setFormData({ email: '', password: '' });
                  setBusinessName('');
                  setLicenseNumber('');
                  setFormErrors({});
                }}
                className="text-sm text-blue-600 hover:text-blue-500 font-medium"
                disabled={isLoading}
              >
                {isSignUp 
                  ? 'Already registered? Sign in' 
                  : "Want to become a vendor? Apply now"
                }
              </button>
            </div>

            {/* Demo Credentials */}
            {!isSignUp && (
              <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <p className="text-sm text-amber-800 font-medium mb-2">Demo Access:</p>
                <p className="text-xs text-amber-700 mb-3">
                  For testing purposes, use any valid business email and password (8+ characters)
                </p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleDemoLogin}
                  className="w-full border-amber-300 text-amber-700 hover:bg-amber-100 h-9"
                  disabled={isLoading}
                >
                  Fill Demo Credentials
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-8 text-sm text-gray-600">
          <p>© 2024 ExchangeWise. All rights reserved.</p>
          <p className="mt-1">Secure vendor portal with advanced business tools</p>
        </div>
      </div>
    </div>
  );
}